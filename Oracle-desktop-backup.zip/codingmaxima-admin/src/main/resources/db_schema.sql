CREATE TABLE `problems` (
  `id` varchar(255) NOT NULL,
  `problem_language` varchar(15) DEFAULT NULL,
  `problem_statement` longtext,
  `solution_code` longtext,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `test_cases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `testcase_no` int DEFAULT NULL,
  `input` varchar(255) DEFAULT NULL,
  `output` varchar(255) DEFAULT NULL,
  `marks` int DEFAULT NULL,
  `problem_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`problem_id`) REFERENCES `problems` (`id`)
);
