package com.codingmaxima.admin.constants;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum LanguageResourceLimit {
    JAVA(1000, 256 * 1024 * 1024),
    PYTHON3(2000, 128 * 1024 * 1024),
    C(800, 64 * 1024 * 1024),
    CPP(800, 64 * 1024 * 1024);

    private LanguageResourceLimit(int timeLimit, int spaceLimit) {
        this.timeLimit = timeLimit;
        this.spaceLimit = spaceLimit;
    }

    public static Map<String, LanguageResourceLimit> JUDGE_LANGUAGE_RESOURCE_LIMIT = Arrays.stream(LanguageResourceLimit.values())
            .collect(Collectors.toMap(Enum::toString, e -> e));

    private final int timeLimit;
    private final int spaceLimit;

    public int timeLimit() {
        return timeLimit;
    }

    public int spaceLimit() {
        return spaceLimit;
    }

}
