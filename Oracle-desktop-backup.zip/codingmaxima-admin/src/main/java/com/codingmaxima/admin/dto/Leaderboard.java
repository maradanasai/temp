package com.codingmaxima.admin.dto;

import com.codingmaxima.admin.repository.entity.User;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import javax.persistence.Id;
import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@Accessors(chain = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Leaderboard {
    @Id
    @EqualsAndHashCode.Include
    private Integer id;
    private String courseId;
    private Integer points;
    private List<User> users;
    private Integer problemsSolvedCount;
}
