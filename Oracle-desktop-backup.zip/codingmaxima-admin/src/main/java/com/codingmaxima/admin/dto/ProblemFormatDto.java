package com.codingmaxima.admin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@Accessors(chain = true)
public class ProblemFormatDto {
    @JsonProperty("problem_id")
    private String problemId;

    @JsonProperty("language_id")
    private String languageId;

    @JsonProperty("title")
    private String title;

    @JsonProperty("problem_statement")
    private String problemStatement;

    @JsonProperty("solution_code")
    private String solutionCode;

    @JsonProperty("test_cases")
    private List<TestCaseDto> testCases;
}
