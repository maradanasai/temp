package com.codingmaxima.admin.exception;

import java.util.Collections;
import java.util.List;

public class ValidationException extends RuntimeException {
	private final List<ErrorData> errors;

    public ValidationException(ErrorData errorData) {
        this.errors = Collections.singletonList(errorData);
    }

    public ValidationException(List<ErrorData> data) {
        this.errors = data;
    }

    public List<ErrorData> getErrors() {
        return errors;
    }
}
