package com.codingmaxima.admin.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AdminConfig {
}
