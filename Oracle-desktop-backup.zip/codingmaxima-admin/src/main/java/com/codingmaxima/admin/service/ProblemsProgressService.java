package com.codingmaxima.admin.service;

import com.codingmaxima.admin.dto.ProblemsProgressDto;
import com.codingmaxima.admin.exception.ErrorData;
import com.codingmaxima.admin.exception.ValidationException;
import com.codingmaxima.admin.mapper.ProblemsProgressMapper;
import com.codingmaxima.admin.repository.ProblemsProgressRepository;
import com.codingmaxima.admin.repository.UserRepository;
import com.codingmaxima.admin.repository.entity.ProblemsProgress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ProblemsProgressService {
    @Autowired
    private ProblemsProgressRepository progressRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private BatchService batchService;

    @Autowired
    private ProblemService problemService;

    @Autowired
    private ProblemsProgressMapper progressMapper;

    @Autowired
    private UserRepository userRepository;

    public ProblemsProgressDto addProblemProgressDetails(ProblemsProgressDto progressDto) {
        if (!userService.isUserExists(progressDto.getStudentId())) {
            throw new ValidationException(new ErrorData("400", null,
                    "User did not exist with id: " + progressDto.getStudentId()));
        }

        if (!batchService.isBatchExists(progressDto.getBatchId())) {
            throw new ValidationException(new ErrorData("400", null,
                    "Batch with id: " + progressDto.getBatchId() + "doesn't exist"));
        }

        if (!problemService.exists(progressDto.getProblemId())) {
            throw new ValidationException(new ErrorData("400", null,
                    "Problem with id: " + progressDto.getProblemId() + "doesn't exist"));
        }

        ProblemsProgress progress = progressRepository.findByStudentIdAndBatchIdAndProblemId(
                progressDto.getStudentId(),
                progressDto.getBatchId(),
                progressDto.getProblemId());

        if (Objects.nonNull(progress)) {
            progress.setSolutionCode(progressDto.getSolutionCode());
            progress.setSolutionLanguage(progressDto.getSolutionLanguage());
            progress.setPoints(progressDto.getPoints());
            progressRepository.save(progress);
        } else {
            progressRepository.save(progressMapper.fromProblemsProgressDto(progressDto));
        }

        return progressDto;
    }

    public Map<String, Integer> getProblemsLeaderBoardDetailsBy(String batchId) {
        List<ProblemsProgress> progresses = progressRepository.findAllByBatchId(batchId);

        if (Objects.isNull(progresses) || progresses.isEmpty()) return Collections.emptyMap();

        Map<String, Integer> result = progresses
                .stream()
                .collect(Collectors.groupingBy(ProblemsProgress::getStudentId,
                        //LinkedHashMap::new,
                        Collectors.summingInt(ProblemsProgress::getPoints)));

        Map<String, Integer> finalResult = new LinkedHashMap<>();
        result
                .entrySet()
                .stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .forEachOrdered(e -> finalResult.put(e.getKey(), e.getValue()));

        return finalResult;
    }

}
