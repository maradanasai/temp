package com.codingmaxima.admin.mapper;

import com.codingmaxima.admin.dto.BatchDto;
import com.codingmaxima.admin.repository.entity.Batch;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface BatchMapper {
    BatchDto toBatchDto(Batch batch);
    Batch fromBatchDto(BatchDto batchDto);
}
