package com.codingmaxima.admin.validation;

import com.codingmaxima.admin.dto.ProblemFormatDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

import java.time.Duration;
import java.util.*;

import static com.codingmaxima.admin.constants.LanguageResourceLimit.JUDGE_LANGUAGE_RESOURCE_LIMIT;
import static com.codingmaxima.admin.constants.Constants.*;


@Component
public class UpdateProblemFormatValidator extends AbstractProblemFormatValidator {
    private static final Logger LOG = LoggerFactory.getLogger(UpdateProblemFormatValidator.class);

    @Override
    protected boolean isProblemExists(Errors errors, ProblemFormatDto problemFormatDto) {
        if (!problemService.exists(problemFormatDto.getProblemId())) {
            errors.rejectValue(PROBLEM_ID_FIELD, "400", "Problem id does not exist: " + problemFormatDto.getProblemId());
            return true;
        }
        return false;
    }

    @Override
    protected void saveProblemDetailsIfVerified(Errors errors, ProblemFormatDto problemFormatDto) {
        Map<String, Object> submissionBody = new HashMap<>();
        submissionBody.put(JUDGE_PROBLEM_ID_FIELD, problemFormatDto.getProblemId());
        submissionBody.put(JUDGE_SOLUTION_CODE_FIELD, problemFormatDto.getSolutionCode());
        submissionBody.put(JUDGE_LANGUAGE_ID_FIELD, problemFormatDto.getLanguageId());
        submissionBody.put(JUDGE_TIME_LIMIT_FIELD, JUDGE_LANGUAGE_RESOURCE_LIMIT.get(problemFormatDto.getLanguageId()).timeLimit());
        submissionBody.put(JUDGE_SPACE_LIMIT_FIELD, JUDGE_LANGUAGE_RESOURCE_LIMIT.get(problemFormatDto.getLanguageId()).spaceLimit());
        submissionBody.put(TEST_CASES_PER_PROB, problemFormatDto.getTestCases());
        submissionBody.put("test", "true");

        List<Map<String, Object>> result = Collections.emptyList();
        ProblemFormatDto backUpCopy = null;
        try {
            backUpCopy = problemService.findAnExistingProblem(problemFormatDto.getProblemId());
            result = webClient.post()
                    .uri("/submission")
                    .bodyValue(submissionBody)
                    .retrieve()
                    .bodyToFlux(new ParameterizedTypeReference<ServerSentEvent<Map<String, Object>>>() {})
                    .map(ServerSentEvent::data)
                    .collectList()
                    .block(Duration.ofMinutes(1));
        } catch (Exception e) {
            errors.rejectValue(PROBLEM_ID_FIELD, e.toString());
            LOG.error("Exception in saveProblemDetailsIfVerified: ", e);
        }

        if (Objects.isNull(result) || result.isEmpty()) {
            LOG.error("Update problem id {} submission result is null or empty", problemFormatDto.getProblemId());
            problemService.updateExistingProblem(backUpCopy);
            return;
        }

        if (result.get(0).containsKey(RESULT_COMPILE) && !((String) result.get(0).get(RESULT_COMPILE)).isEmpty()
                && !result.get(0).get(RESULT_COMPILE).equals("compiled successfully")) {
            problemService.updateExistingProblem(backUpCopy);
            errors.rejectValue(PROBLEM_ID_FIELD, "400", "compile time errors: " + result.get(0).get(RESULT_COMPILE));
            return;
        }

        if (result.get(0).containsKey(RESULT_ERROR) && !((String) result.get(0).get(RESULT_ERROR)).isEmpty()) {
            problemService.updateExistingProblem(backUpCopy);
            errors.rejectValue(PROBLEM_ID_FIELD, "400", "judge errors: " + result.get(0).get(RESULT_ERROR));
            return;
        }

        Map<String, Object> tempResult = result
                .stream()
                .filter(r -> Objects.nonNull(r.get(RESULT_STATUS)) && !r.get(RESULT_STATUS).equals(ACCEPTED_STATUS_CODE))
                .findFirst()
                .orElse(Collections.emptyMap());
        if (!tempResult.isEmpty()) {
            problemService.updateExistingProblem(backUpCopy);
            errors.rejectValue(PROBLEM_ID_FIELD, "400",
                    String.format("Test case %s is failed for problem id: %s. Input: %s, Expected: %s, Actual: %s",
                            tempResult.get(RESULT_TESTCASE_NUMBER),
                            tempResult.get(RESULT_PROBLEM_ID),
                            tempResult.get(RESULT_INPUT),
                            tempResult.get(RESULT_EXPECTED_OUTPUT),
                            tempResult.get(RESULT_ACTUAL_OUTPUT)));
            return;
        }

        problemService.updateExistingProblem(problemFormatDto);
    }
}
