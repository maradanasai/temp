package com.codingmaxima.admin.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Setter
@Getter
@NoArgsConstructor
@Accessors(chain = true)
@ToString
public class EmailNotificationDto {
    private String subject;
    private String messageBody;
    private String recipientEmail;
}
