package com.codingmaxima.admin.service;

import com.codingmaxima.admin.dto.BatchDto;
import com.codingmaxima.admin.dto.EmailNotificationDto;
import com.codingmaxima.admin.exception.ErrorData;
import com.codingmaxima.admin.exception.ValidationException;
import com.codingmaxima.admin.mapper.BatchMapper;
import com.codingmaxima.admin.notification.EmailNotificationService;
import com.codingmaxima.admin.repository.BatchRepository;
import com.codingmaxima.admin.repository.UserRepository;
import com.codingmaxima.admin.repository.entity.Batch;
import com.codingmaxima.admin.repository.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;


@Service
public class BatchService {
    @Autowired
    private BatchRepository batchRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailNotificationService emailNotificationService;

    @Autowired
    private BatchMapper batchMapper;

    public BatchDto addNewBatch(BatchDto batchDto) {
        if (isBatchExists(batchDto.getId())) {
            throw new ValidationException(new ErrorData("400", null,
                    "Cannot create new batch with id: " + batchDto.getId() + ", already exists"));
        }

        Batch batch = batchMapper.fromBatchDto(batchDto);
        batch.setStudents(
                batchDto.getStudentIds()
                        .stream()
                        .map(studentId -> userRepository.findById(studentId)
                                .orElseThrow(() -> new ValidationException(new ErrorData("400", null,
                                        "user doesn't exist with id: " + studentId)))
                        )
                        .collect(Collectors.toList()));

        batchRepository.save(batch);
        return batchDto;
    }

    public BatchDto updateBatchStudentList(String batchId, List<String> studentIds) {
        Optional<Batch> batch = batchRepository.findById(batchId);
        if (!batch.isPresent()) {
            throw new ValidationException(new ErrorData("400", null,
                    "Batch with id: " + batchId + "doesn't exist"));
        }

        batch.get()
                .setStudents(
                        studentIds.stream()
                                .map(studentId -> userRepository.findById(studentId)
                                        .orElseThrow(() -> new ValidationException(new ErrorData("400", null,
                                                "user doesn't exist with id: " + studentId)))
                                )
                                .collect(Collectors.toList())
                );
        batchRepository.save(batch.get());

        BatchDto result =  batchMapper.toBatchDto(batch.get());
        result.setStudentIds(
            batch.get()
                    .getStudents()
                    .stream()
                    .map(User::getId)
                    .collect(Collectors.toList()));

        return result;
    }

    public boolean updateNextClassDetails(String batchId, LocalDateTime nextClassTime, String nextClassUrl) {
        Optional<Batch> batch = batchRepository.findById(batchId);
        if (!batch.isPresent()) {
            throw new ValidationException(new ErrorData("400", null,
                    "Batch with id: " + batchId + "doesn't exist"));
        }

        batch.get()
                .setNextClassUrl(nextClassUrl)
                .setNextClassTime(nextClassTime);
        batchRepository.save(batch.get());

        CompletableFuture.runAsync(() ->
            emailNotificationService.sendEmailNotifications(
                    batch.get()
                            .getStudents()
                            .stream()
                            .map(User::getId)
                            .map(e -> new EmailNotificationDto()
                                    .setRecipientEmail(e)
                                    .setSubject("CODINGMAXIMA - NEXT CLASS DETAILS") // TODO: change this later
                                    .setMessageBody("Next class url: " + batch.get().getNextClassUrl() + ", time: " + batch.get().getNextClassTime())
                            )
                            .collect(Collectors.toList())));

        return true;
    }

    public BatchDto getBatchDetails(String batchId) {
        Batch batch = batchRepository.findById(batchId)
                .orElseThrow(() -> new ValidationException(new ErrorData("400", null,
                        "Batch with id: " + batchId + "doesn't exist")));

        BatchDto result = batchMapper.toBatchDto(batch);
        result.setStudentIds(
                batch.getStudents()
                        .stream()
                        .map(User::getId)
                        .collect(Collectors.toList()));

        return result;
    }

    public boolean isBatchExists(String batchId) {
        return batchRepository.existsById(batchId);
    }
}
