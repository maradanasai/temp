package com.codingmaxima.admin.service;

import com.codingmaxima.admin.dto.DashboardDto;
import com.codingmaxima.admin.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// TODO: TBD
@Service
public class UserDashboardService {
    @Autowired
    private UserRepository userRepository;

    public DashboardDto getUserDashBoard() {
        return null;
    }

}
