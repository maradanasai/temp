package com.codingmaxima.admin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;


@Setter
@Getter
@NoArgsConstructor
@Accessors(chain = true)
@ToString
public class ProblemsProgressDto {
    @JsonProperty(required = true)
    private String studentId;

    @JsonProperty(required = true)
    private String batchId;

    @JsonProperty(required = true)
    private String problemId;

    @JsonProperty(required = true)
    private String solutionCode;

    @JsonProperty(required = true)
    private String solutionLanguage;

    @JsonProperty(required = true)
    private Integer points;
}
