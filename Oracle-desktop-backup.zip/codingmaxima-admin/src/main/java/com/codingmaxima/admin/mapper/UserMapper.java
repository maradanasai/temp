package com.codingmaxima.admin.mapper;

import com.codingmaxima.admin.dto.UserDto;
import com.codingmaxima.admin.repository.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface UserMapper {
    UserDto toUserDto(User user);
    User fromUserDto(UserDto userDto);
    List<UserDto> toUserDtos(List<User> users);
}
