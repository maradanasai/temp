package com.codingmaxima.admin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@Accessors(chain = true)
@ToString
public class TopicDto {
    @JsonProperty
    private Integer id;

    @JsonProperty(required = true)
    private String name;

    /*@JsonProperty
    private List<String> problemIds;

    @JsonProperty
    private String videoId;

    @JsonProperty
    private List<TopicDto> subtopics;*/
}
