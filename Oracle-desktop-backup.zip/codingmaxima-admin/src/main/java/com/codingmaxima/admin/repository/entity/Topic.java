package com.codingmaxima.admin.repository.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.Column;
import javax.persistence.GenerationType;
import java.util.List;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Accessors(chain = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Topic {
    @Id
    @EqualsAndHashCode.Include
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String name;

    @Column(name = "course_id_fk")
    private String course;

    // TODO: later will deal with subtopic hierarchy
    /*@OneToMany(targetEntity = Problem.class, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = COL_TOPIC_ID + "_fk", referencedColumnName = COL_TOPIC_ID)
    private List<Problem> problems;

    @OneToMany(targetEntity = Topic.class, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = COL_TOPIC_ID + "_fk", referencedColumnName = COL_TOPIC_ID)
    private List<Video> videos;

    @OneToMany(targetEntity = Topic.class, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = COL_TOPIC_ID + "_fk", referencedColumnName = COL_TOPIC_ID)
    private List<Topic> subtopics;*/
}
