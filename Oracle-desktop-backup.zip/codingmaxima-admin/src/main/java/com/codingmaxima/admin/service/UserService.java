package com.codingmaxima.admin.service;

import com.codingmaxima.admin.dto.UserDto;
import com.codingmaxima.admin.exception.ErrorData;
import com.codingmaxima.admin.exception.ValidationException;
import com.codingmaxima.admin.mapper.UserMapper;
import com.codingmaxima.admin.repository.UserRepository;
import com.codingmaxima.admin.repository.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private BatchService batchService;

    public UserDto registerUser(UserDto userDto) {
        if (isUserExists(userDto.getId())) {
            throw new ValidationException(new ErrorData("400", null, "User already exists with id: " + userDto.getId()));
        }

        userRepository.save(userMapper.fromUserDto(userDto));
        return userDto;
    }

    public UserDto updateUserDetails(UserDto userDto) {
        if (!isUserExists(userDto.getId())) {
            throw new ValidationException(new ErrorData("400", null, "User did not exist with id: " + userDto.getId()));
        }

        userRepository.save(userMapper.fromUserDto(userDto));
        return userDto;
    }

    public UserDto findUserDetails(String userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ValidationException(
                        new ErrorData("400", null, "User did not exist with id: " + userId)));
        return new UserDto()
                .setId(user.getId())
                .setBatchId(user.getBatchId())
                .setName(user.getName())
                .setRole(user.getRole());
    }

    public boolean deleteUserDetails(String userId) {
        if (!isUserExists(userId)) {
            throw new ValidationException(new ErrorData("400", null, "User did not exist with id: " + userId));
        }

        userRepository.deleteById(userId);
        return true;
    }

    public List<UserDto> findAllUserDetailsFrom(String batchId) {
        if (!batchService.isBatchExists(batchId)) {
            throw new ValidationException(new ErrorData("400", null,
                    "Batch with id: " + batchId + "doesn't exist"));
        }

        return userMapper.toUserDtos(userRepository.findAllByBatchId(batchId));
    }

    public boolean isUserExists(String userId) {
        return userRepository.existsById(userId);
    }
}
