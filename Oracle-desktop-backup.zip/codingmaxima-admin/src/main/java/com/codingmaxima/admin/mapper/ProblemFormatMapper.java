package com.codingmaxima.admin.mapper;

import com.codingmaxima.admin.dto.ProblemFormatDto;
import com.codingmaxima.admin.repository.entity.Problem;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ProblemFormatMapper {
    ProblemFormatDto toProblemFormatDto(Problem problem);
    Problem fromProblemFormatDto(ProblemFormatDto problemFormatDto);
}
