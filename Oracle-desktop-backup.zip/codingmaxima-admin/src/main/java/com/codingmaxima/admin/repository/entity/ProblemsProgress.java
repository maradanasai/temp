package com.codingmaxima.admin.repository.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import javax.persistence.*;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Accessors(chain = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ProblemsProgress {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @EqualsAndHashCode.Include
    private Integer id;

    @Column(nullable = false)
    private String studentId;

    @Column(nullable = false)
    private String batchId;

    @Column(nullable = false)
    private String problemId;

    @Lob
    private String solutionCode;

    private String solutionLanguage;

    private Integer points;
}
