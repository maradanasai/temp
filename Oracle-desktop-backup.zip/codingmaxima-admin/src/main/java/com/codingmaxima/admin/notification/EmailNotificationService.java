package com.codingmaxima.admin.notification;

import com.codingmaxima.admin.dto.EmailNotificationDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmailNotificationService {
    private static final Logger LOG = LoggerFactory.getLogger(EmailNotificationService.class);

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String sender;

    public void sendEmailNotifications(List<EmailNotificationDto> details) {
        details
                .stream()
                .map(emailNotificationDto -> {
                    SimpleMailMessage mailMessage = new SimpleMailMessage();
                    mailMessage.setSubject(emailNotificationDto.getSubject());
                    mailMessage.setFrom(sender);
                    mailMessage.setTo(emailNotificationDto.getRecipientEmail());
                    mailMessage.setText(emailNotificationDto.getMessageBody());
                    return mailMessage;
                })
                .forEach(mailMessage -> {
                    try {
                        javaMailSender.send(mailMessage);
                    } catch (Exception e) {
                        LOG.error("Exception in sending email notifications", e);
                    }
                });
    }
}
