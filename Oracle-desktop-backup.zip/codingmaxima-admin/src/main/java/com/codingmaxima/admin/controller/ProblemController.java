package com.codingmaxima.admin.controller;

import com.codingmaxima.admin.dto.ProblemFormatDto;
import com.codingmaxima.admin.service.ProblemService;
import com.codingmaxima.admin.validation.core.DtoValidator;
import com.codingmaxima.admin.validation.NewProblemFormatValidator;
import com.codingmaxima.admin.validation.UpdateProblemFormatValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.codingmaxima.admin.constants.Constants.ROLE_ADMIN;
import static com.codingmaxima.admin.constants.Constants.ROLE_STUDENT;

@RestController
@RequestMapping(value = "/problem")
public class ProblemController {

    @Autowired
    private ProblemService problemService;

    @PostMapping
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<ProblemFormatDto> addNewProblem(
            @DtoValidator(customValidator = NewProblemFormatValidator.class)
            @RequestBody ProblemFormatDto problemFormatDto) {
        return new ResponseEntity<>(problemFormatDto, HttpStatus.ACCEPTED);
    }

    @PutMapping
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<ProblemFormatDto> updateProblem(
            @DtoValidator(customValidator = UpdateProblemFormatValidator.class)
            @RequestBody ProblemFormatDto problemFormatDto) {
        return new ResponseEntity<>(problemService.updateExistingProblem(problemFormatDto), HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/{problemId}")
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<Boolean> deleteProblem(@PathVariable String problemId) {
        return new ResponseEntity<>(problemService.deleteExistingProblem(problemId), HttpStatus.ACCEPTED);
    }

    @GetMapping("/{problemId}")
    @PreAuthorize(ROLE_STUDENT)
    public ResponseEntity<ProblemFormatDto> findProblem(@PathVariable String problemId) {
        return new ResponseEntity<>(problemService.findAnExistingProblem(problemId), HttpStatus.ACCEPTED);
    }

    @GetMapping
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<List<ProblemFormatDto>> findAllProblems() {
        return new ResponseEntity<>(problemService.findAllProblems(), HttpStatus.ACCEPTED);
    }
}
