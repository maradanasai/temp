package com.codingmaxima.admin.repository;

import com.codingmaxima.admin.repository.entity.ProblemsProgress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProblemsProgressRepository extends JpaRepository<ProblemsProgress, Integer> {
    ProblemsProgress findByStudentIdAndBatchIdAndProblemId(String studentId, String batchId, String problemId);

    List<ProblemsProgress> findAllByBatchId(String batchId);
}
