package com.codingmaxima.admin.mapper;

import com.codingmaxima.admin.dto.TestCaseDto;
import com.codingmaxima.admin.repository.entity.TestCase;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface TestCaseMapper {
    TestCaseDto toTestCaseDto(TestCase testCase);
    List<TestCaseDto> toTestCaseDtos(List<TestCase> testCase);
    TestCase fromTestCaseDto(TestCaseDto testCaseDto);
}
