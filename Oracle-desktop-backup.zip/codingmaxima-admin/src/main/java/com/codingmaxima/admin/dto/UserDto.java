package com.codingmaxima.admin.dto;

import com.codingmaxima.admin.constants.Role;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@Accessors(chain = true)
@ToString
public class UserDto {
    @JsonProperty(required = true)
    private String id;

    @JsonProperty(required = true)
    private String name;

    @JsonProperty
    private Role role;

    @JsonProperty
    private String batchId;

    /*@JsonProperty
    private List<CourseDto> subscribedCourses;*/
}
