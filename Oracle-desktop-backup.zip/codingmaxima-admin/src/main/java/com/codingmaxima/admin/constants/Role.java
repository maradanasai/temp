package com.codingmaxima.admin.constants;

public enum Role {
    ROLE_STUDENT, ROLE_ADMIN
}
