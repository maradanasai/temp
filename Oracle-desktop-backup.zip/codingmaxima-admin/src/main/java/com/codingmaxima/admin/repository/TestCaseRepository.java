package com.codingmaxima.admin.repository;

import com.codingmaxima.admin.repository.entity.TestCase;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TestCaseRepository extends JpaRepository<TestCase, Integer> {
    @Query("SELECT ts FROM Problem p join p.testCases ts WHERE p.problemId = :problemId")
    List<TestCase> getAllTestCasesByProblemId(@Param("problemId") String problemId);
}
