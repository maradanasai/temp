package com.codingmaxima.admin.dto;

import com.codingmaxima.admin.repository.entity.User;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@Accessors(chain = true)
@ToString
public class BatchDto {
    @JsonProperty(required = true)
    private String id;

    @JsonProperty(required = true)
    private String name;

    @JsonProperty
    private List<String> studentIds;

    @JsonProperty
    private String nextClassUrl;

    @JsonProperty
    private LocalDateTime nextClassTime;

    @JsonProperty(required = true)
    private LocalDateTime batchStartDate;

    @JsonProperty
    private LocalDateTime batchEndDate;
}
