package com.codingmaxima.admin.controller;

import com.codingmaxima.admin.constants.Constants;
import com.codingmaxima.admin.dto.TestCaseDto;

import com.codingmaxima.admin.service.ProblemService;
import com.codingmaxima.admin.service.TestCaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * This API controller is strictly for judge service, not for external use.
 **/
@RestController
@RequestMapping(Constants.JUDGE_API_CONTROLLER_BASE_URI)
public class JudgeDataController {
    @Autowired
    private ProblemService problemService;

    @Autowired
    private TestCaseService testCaseService;

    @GetMapping("/testcases/{offset}/{limit}")
    public List<TestCaseDto> findAllTestCases(@PathVariable Integer offset,
                                              @PathVariable Integer limit) {
        return testCaseService.findAllTestCases(offset, limit);
    }

    @GetMapping("/testcases/{problemId}")
    public List<TestCaseDto> findAllTestCases(@PathVariable String problemId) {
        return testCaseService.findAllTestCases(problemId);
    }

    @GetMapping("/problem/ids")
    public List<String> findAllProblemIds() {
        return problemService.findAllProblemIds();
    }
}
