package com.codingmaxima.admin.exception;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@ControllerAdvice
public class GlobalControllerExceptionHandler {
    private static final Logger LOG = LoggerFactory.getLogger(GlobalControllerExceptionHandler.class);

	@ExceptionHandler(value = ValidationException.class)
    @ResponseBody
    public ResponseEntity<List<ErrorData>> validationException(ValidationException exception) {
        return new ResponseEntity<>(exception.getErrors(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = RuntimeException.class)
    @ResponseBody
    public ResponseEntity<String> defaultExceptionHandler(RuntimeException e) {
        LOG.error("Internal Error:", e);
        return new ResponseEntity<>(NestedExceptionUtils.getMostSpecificCause(e).toString(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
