package com.codingmaxima.admin.service;

import com.codingmaxima.admin.dto.CourseDto;
import com.codingmaxima.admin.exception.ErrorData;
import com.codingmaxima.admin.exception.ValidationException;
import com.codingmaxima.admin.mapper.CourseMapper;
import com.codingmaxima.admin.repository.CourseRepository;
import com.codingmaxima.admin.repository.ProblemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseService {
    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private ProblemRepository problemRepository;

    @Autowired
    private CourseMapper courseMapper;

    public CourseDto addCourseDetails(CourseDto courseDto) {
        if (exists(courseDto.getId())) {
            throw new ValidationException(
                    new ErrorData("400", "courseId", "Course " + courseDto.getName() + " already exists"));
        }

        courseRepository.save(courseMapper.fromCourseDto(courseDto));
        return courseDto;
    }

    public CourseDto updateCourseDetails(CourseDto courseDto) {
        if (!exists(courseDto.getId())) {
            throw new ValidationException(
                    new ErrorData("400", "courseId", "Course " + courseDto.getName() + " not exists"));
        }

        courseRepository.save(courseMapper.fromCourseDto(courseDto));
        return courseDto;
    }

    public CourseDto getCourseDetails(String courseId) {
        if (!exists(courseId)) {
            throw new ValidationException(
                    new ErrorData("400", "courseId", "Course " + courseId + " not exists"));
        }

        return courseMapper.toCourseDto(courseRepository.findById(courseId).get());
    }

    public boolean deleteCourse(String courseId) {
        if (!exists(courseId)) {
            throw new ValidationException(
                    new ErrorData("400", "courseId", "Course " + courseId + " not exists"));
        }

        courseRepository.deleteById(courseId);
        return true;
    }

    private boolean exists(String courseId) {
        return courseRepository.existsById(courseId);
    }
}
