package com.codingmaxima.admin.validation.core;

import com.codingmaxima.admin.exception.ErrorData;
import com.codingmaxima.admin.exception.ValidationException;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ValidationResultAnalyser {
    public void analyseValidationResult(Errors bindingResult) {
        List<ErrorData> errors = bindingResult.getFieldErrors()
                .stream()
                .map(this::buildErrorData)
                .collect(Collectors.toList());

        if (!errors.isEmpty()) {
            throw new ValidationException(errors);
        }
    }

    protected ErrorData buildErrorData(FieldError error) {
        return new ErrorData(error.getField(), error.getDefaultMessage(), error.getCode());
    }

}
