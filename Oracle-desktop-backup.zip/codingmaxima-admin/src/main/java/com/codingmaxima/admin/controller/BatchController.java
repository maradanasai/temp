package com.codingmaxima.admin.controller;

import com.codingmaxima.admin.dto.BatchDto;
import com.codingmaxima.admin.service.BatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.codingmaxima.admin.constants.Constants.ROLE_ADMIN;
import static com.codingmaxima.admin.constants.Constants.ROLE_STUDENT;

@RestController
@RequestMapping(value = "/batch")
public class BatchController {
    @Autowired
    private BatchService batchService;

    @PostMapping
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<BatchDto> addNewBatch(@RequestBody BatchDto batchDto) {
        return ResponseEntity.ok(batchService.addNewBatch(batchDto));
    }

    @PutMapping("/{batchId}")
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<BatchDto> updateStudentList(@PathVariable String batchId,
                                                      @RequestBody List<String> studentIds) {
        return ResponseEntity.ok(batchService.updateBatchStudentList(batchId, studentIds));
    }

    @PatchMapping
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<Boolean> updateNextClassDetails(@RequestBody BatchDto batchDto) {
        return ResponseEntity.ok(
                batchService.updateNextClassDetails(batchDto.getId(),
                        batchDto.getNextClassTime(),
                        batchDto.getNextClassUrl()));
    }

    @GetMapping("/{batchId}")
    @PreAuthorize(ROLE_STUDENT)
    public ResponseEntity<BatchDto> findBatchDetails(@PathVariable String batchId) {
        return ResponseEntity.ok(batchService.getBatchDetails(batchId));
    }
}
