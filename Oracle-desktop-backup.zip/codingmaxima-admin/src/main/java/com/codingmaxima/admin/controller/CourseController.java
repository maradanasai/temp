package com.codingmaxima.admin.controller;

import com.codingmaxima.admin.dto.CourseDto;
import com.codingmaxima.admin.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;

import static com.codingmaxima.admin.constants.Constants.ROLE_ADMIN;
import static com.codingmaxima.admin.constants.Constants.ROLE_STUDENT;

@RestController
@RequestMapping("/course")
public class CourseController {
    @Autowired
    private CourseService courseService;

    @PostMapping
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<CourseDto> addNewCourseDetails(@RequestBody CourseDto courseDto) {
        return ResponseEntity.ok(courseService.addCourseDetails(courseDto));
    }

    @PutMapping
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<CourseDto> updateCourseDetails(@RequestBody CourseDto courseDto) {
        return ResponseEntity.ok(courseService.updateCourseDetails(courseDto));
    }

    @DeleteMapping("/{courseId}")
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<Boolean> deleteCourse(@PathVariable String courseId) {
        return ResponseEntity.ok(courseService.deleteCourse(courseId));
    }

    @GetMapping("/{courseId}")
    @PreAuthorize(ROLE_STUDENT)
    public ResponseEntity<CourseDto> getCourseDetails(@PathVariable String courseId) {
        return ResponseEntity.ok(courseService.getCourseDetails(courseId));
    }
}
