package com.codingmaxima.admin.mapper;

import com.codingmaxima.admin.dto.ProblemsProgressDto;
import com.codingmaxima.admin.repository.entity.ProblemsProgress;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ProblemsProgressMapper {
    ProblemsProgress fromProblemsProgressDto(ProblemsProgressDto progressDto);
}
