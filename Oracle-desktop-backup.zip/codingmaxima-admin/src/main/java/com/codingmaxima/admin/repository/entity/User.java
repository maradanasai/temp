package com.codingmaxima.admin.repository.entity;

import com.codingmaxima.admin.constants.Role;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;


@Entity
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class User {
    @Id
    @EqualsAndHashCode.Include
    private String id;

    private String name;

    @Enumerated(EnumType.STRING)
    private Role role;

    @Column(name = "batch_id_fk")
    private String batchId;

    @ManyToMany(cascade = CascadeType.ALL)
    private List<Course> subscribedCourses;
}
