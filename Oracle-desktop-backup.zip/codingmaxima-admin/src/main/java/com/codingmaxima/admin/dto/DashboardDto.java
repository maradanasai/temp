package com.codingmaxima.admin.dto;

public class DashboardDto {
}
