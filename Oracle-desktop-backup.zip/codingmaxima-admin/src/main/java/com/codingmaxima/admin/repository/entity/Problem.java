package com.codingmaxima.admin.repository.entity;

import java.util.List;
import javax.persistence.*;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Problem {
    @Id
    @EqualsAndHashCode.Include
    @Column(name = "problem_id")
    private String problemId;

    @Column(name = "problem_language")
    private String languageId;

    @Column(name = "title")
    private String title;

    @Lob
    @Column(name = "problem_statement")
    private String problemStatement;

    @Lob
    @Column(name = "solution_code")
    private String solutionCode;

    @OneToMany(targetEntity = TestCase.class, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "problem_id_fk", referencedColumnName = "problem_id")
    private List<TestCase> testCases;
}
