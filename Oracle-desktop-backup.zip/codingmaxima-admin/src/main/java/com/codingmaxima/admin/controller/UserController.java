package com.codingmaxima.admin.controller;

import com.codingmaxima.admin.dto.UserDto;
import com.codingmaxima.admin.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.codingmaxima.admin.constants.Constants.ROLE_ADMIN;
import static com.codingmaxima.admin.constants.Constants.ROLE_STUDENT;

@RestController
@RequestMapping(value = "/user")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping
    //@PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<UserDto> addUser(@RequestBody UserDto userDto) {
        return ResponseEntity.ok(userService.registerUser(userDto));
    }

    @PutMapping
    @PreAuthorize(ROLE_STUDENT)
    public ResponseEntity<UserDto> updateUser(@RequestBody UserDto userDto) {
        return ResponseEntity.ok(userService.updateUserDetails(userDto));
    }

    @DeleteMapping("/{userId}")
    @PreAuthorize(ROLE_ADMIN)
    public ResponseEntity<Boolean> deleteUser(@PathVariable String userId) {
        return ResponseEntity.ok(userService.deleteUserDetails(userId));
    }

    @GetMapping("/{userId}")
    //@PreAuthorize(ROLE_STUDENT)
    public ResponseEntity<UserDto> getUser(@PathVariable String userId) {
        return ResponseEntity.ok(userService.findUserDetails(userId));
    }

    @GetMapping("/all/{batchId}")
    @PreAuthorize(ROLE_STUDENT)
    public ResponseEntity<List<UserDto>> getAllUsers(@PathVariable String batchId) {
        return ResponseEntity.ok(userService.findAllUserDetailsFrom(batchId));
    }
}
