package com.codingmaxima.admin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Setter
@Getter
@NoArgsConstructor
@Accessors(chain = true)
@ToString
public class VideoDto {
    @JsonProperty
    private String id;

    @JsonProperty
    private String name;

    @JsonProperty
    private String url;
}
