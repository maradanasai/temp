package com.codingmaxima.admin.repository.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Accessors(chain = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Batch {
    @Id
    @EqualsAndHashCode.Include
    private String id;

    private String name;

    @OneToMany(orphanRemoval = true)
    @JoinColumn(name = "batch_id_fk", referencedColumnName = "id")
    private List<User> students;

    private String nextClassUrl;

    private LocalDateTime nextClassTime;

    private LocalDateTime batchStartDate;

    private LocalDateTime batchEndDate;
}
