package com.codingmaxima.admin.validation;

import com.codingmaxima.admin.dto.ProblemFormatDto;
import com.codingmaxima.admin.dto.TestCaseDto;
import com.codingmaxima.admin.service.ProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.reactive.function.client.WebClient;

import javax.annotation.PostConstruct;
import java.util.Comparator;

import static com.codingmaxima.admin.constants.LanguageResourceLimit.JUDGE_LANGUAGE_RESOURCE_LIMIT;


public abstract class AbstractProblemFormatValidator implements Validator {
    protected static final String PROBLEM_ID_FIELD = "problemId";
    protected static final String SOLUTION_CODE_FIELD = "solutionCode";
    protected static final String LANGUAGE_ID_FIELD = "languageId";
    protected static final String PROBLEM_STATEMENT_FIELD = "problemStatement";
    protected static final String TITLE_FIELD = "title";
    protected static final String TEST_CASES_FIELD = "testCases";
    protected static final String TIME_LIMIT_FIELD = "timeLimit";
    protected static final String SPACE_LIMIT_FIELD = "spaceLimit";
    protected static final String ACCEPTED_STATUS_CODE = "AC";

    @Autowired
    protected ProblemService problemService;

    @Override
    public boolean supports(Class<?> clazz) {
        return ProblemFormatDto.class.isAssignableFrom(clazz);
    }

    @Value("${codingmaxima.judge.service.broker.url}")
    private String judgeSvcBrokerUrl;

    protected WebClient webClient;

    @PostConstruct
    public void init() {
        webClient = WebClient.builder()
                .baseUrl(judgeSvcBrokerUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    @Override
    public void validate(Object target, Errors errors) {
        ProblemFormatDto problemFormatDto = (ProblemFormatDto) target;
        if (isNullOrEmpty(problemFormatDto.getProblemId())) {
            errors.rejectValue(PROBLEM_ID_FIELD, "400", "Problem Id: %s cannot be null or empty");
        }

        if (isNullOrEmpty(problemFormatDto.getSolutionCode())) {
            errors.rejectValue(SOLUTION_CODE_FIELD, "400", "Solution program cannot be null or empty for Problem Id: " + problemFormatDto.getProblemId());
        }

        if (isNullOrEmpty(problemFormatDto.getLanguageId())) {
            errors.rejectValue(LANGUAGE_ID_FIELD, "400", "languageId cannot be null or empty for Problem Id: " + problemFormatDto.getProblemId());
        }

        if (isNullOrEmpty(problemFormatDto.getProblemStatement())) {
            errors.rejectValue(PROBLEM_STATEMENT_FIELD, "400", "problemStatement cannot be null or empty for Problem Id: " + problemFormatDto.getProblemId());
        }

        if (isNullOrEmpty(problemFormatDto.getTitle())) {
            errors.rejectValue(TITLE_FIELD, "400", "problem title should not be null or empty for Problem Id: " + problemFormatDto.getProblemId());
        }

        if (!JUDGE_LANGUAGE_RESOURCE_LIMIT.containsKey(problemFormatDto.getLanguageId().toUpperCase())) {
            errors.rejectValue(LANGUAGE_ID_FIELD, "400",
                    String.format("languageId: %s cannot be supported for Problem Id: %s. Supported runtimes are: %s",
                            problemFormatDto.getLanguageId(), problemFormatDto.getProblemId(), JUDGE_LANGUAGE_RESOURCE_LIMIT));
        }

        if (problemFormatDto.getTestCases().isEmpty() || problemFormatDto.getTestCases()
                .stream()
                .anyMatch(testCase -> isNullOrEmpty(testCase.getInput()) || isNullOrEmpty(testCase.getOutput()))) {
            errors.rejectValue(TEST_CASES_FIELD, "400", "Oops! Looks like one of the test case data is null or empty for Problem Id: " + problemFormatDto.getProblemId());
        }


        if (problemFormatDto.getTestCases()
                .stream()
                .sorted(Comparator.comparingInt(TestCaseDto::getTestcaseNo))
                .mapToInt(TestCaseDto::getTestcaseNo)
                .sum() != problemFormatDto.getTestCases().size() * (problemFormatDto.getTestCases().size() + 1) / 2) {
            errors.rejectValue(TEST_CASES_FIELD, "400", "All testcases numbers should be in Range 1..n continuous for Problem Id: " + problemFormatDto.getProblemId());
        }

        /*if (problemFormat.getTestCases()
                .stream()
                .mapToInt(TestCase::getMarks)
                .sum() != 100) {
            errors.rejectValue("testCases", "400", "Adding all test cases marks not equals to 100 for Problem Id: " + problemFormat.id());
        }*/
        if (errors.hasErrors()) return;

        // Check the problem directory exists or not
        if (isProblemExists(errors, problemFormatDto)) return;

        // Verify the problem correctness & save
        saveProblemDetailsIfVerified(errors, problemFormatDto);
    }

    protected abstract boolean isProblemExists(Errors errors, ProblemFormatDto problemFormatDto);

    protected abstract void saveProblemDetailsIfVerified(Errors errors, ProblemFormatDto problemFormatDto);

    private static boolean isNullOrEmpty(String value) {
        return value == null || value.isEmpty();
    }
    
}
