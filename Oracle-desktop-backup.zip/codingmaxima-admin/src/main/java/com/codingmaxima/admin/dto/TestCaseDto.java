package com.codingmaxima.admin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Setter
@Getter
@NoArgsConstructor
@Accessors(chain = true)
@ToString
public class TestCaseDto {
    @JsonProperty("testcase_no")
    private Integer testcaseNo;

    @JsonProperty("input")
    private String input;

    @JsonProperty("output")
    private String output;

    @JsonProperty("marks")
    private Integer marks;

    @JsonProperty("problem_id")
    private String problemId;
}
