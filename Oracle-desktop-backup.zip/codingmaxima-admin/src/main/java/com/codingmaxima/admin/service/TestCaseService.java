package com.codingmaxima.admin.service;

import com.codingmaxima.admin.dto.TestCaseDto;
import com.codingmaxima.admin.mapper.TestCaseMapper;
import com.codingmaxima.admin.repository.TestCaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestCaseService {
    @Autowired
    private TestCaseRepository testCaseRepository;

    @Autowired
    private TestCaseMapper testCaseMapper;

    public List<TestCaseDto> findAllTestCases(int offset, int limit) {
        return testCaseMapper.toTestCaseDtos(
                testCaseRepository
                        .findAll(PageRequest.of(offset, limit))
                        .getContent()
        );
    }

    public List<TestCaseDto> findAllTestCases(String problemId) {
        return testCaseMapper.toTestCaseDtos(
            testCaseRepository.getAllTestCasesByProblemId(problemId)
        );
    }
}
