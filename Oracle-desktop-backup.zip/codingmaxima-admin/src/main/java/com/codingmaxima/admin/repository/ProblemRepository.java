package com.codingmaxima.admin.repository;

import com.codingmaxima.admin.repository.entity.Problem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProblemRepository extends JpaRepository<Problem, String> {
    @Query(value = "SELECT p.problemId FROM Problem p")
    List<String> getAllProblemIds();
}
