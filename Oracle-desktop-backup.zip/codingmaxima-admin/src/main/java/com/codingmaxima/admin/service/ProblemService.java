package com.codingmaxima.admin.service;

import com.codingmaxima.admin.exception.ErrorData;
import com.codingmaxima.admin.exception.ValidationException;
import com.codingmaxima.admin.dto.ProblemFormatDto;
import com.codingmaxima.admin.mapper.ProblemFormatMapper;
import com.codingmaxima.admin.repository.ProblemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProblemService {

    @Autowired
    private ProblemRepository problemRepository;

    @Autowired
    private ProblemFormatMapper problemFormatMapper;

    public ProblemFormatDto addNewProblem(ProblemFormatDto problemFormatDto) {
        problemRepository.save(problemFormatMapper.fromProblemFormatDto(problemFormatDto));
        return problemFormatDto;
    }

    public ProblemFormatDto updateExistingProblem(ProblemFormatDto problemFormatDto) {
        problemRepository.save(problemFormatMapper.fromProblemFormatDto(problemFormatDto));
        return problemFormatDto;
    }

    public boolean deleteExistingProblem(String problemId) {
        problemRepository.deleteById(problemId);
        return true;
    }

    public ProblemFormatDto findAnExistingProblem(String problemId) {
        return problemFormatMapper.toProblemFormatDto(problemRepository
                .findById(problemId)
                .orElseThrow(() -> new ValidationException(
                        new ErrorData("400", "id", "Problem details doesn't exist with Id: " + problemId))));
    }

    public List<ProblemFormatDto> findAllProblems() {
        return problemRepository
                .findAll()
                .stream()
                .map(problemFormatMapper::toProblemFormatDto)
                .collect(Collectors.toList());
    }

    public boolean exists(String problemId) {
        return problemRepository.existsById(problemId);
    }

    public List<String> findAllProblemIds() {
        return problemRepository.getAllProblemIds();
    }
}
