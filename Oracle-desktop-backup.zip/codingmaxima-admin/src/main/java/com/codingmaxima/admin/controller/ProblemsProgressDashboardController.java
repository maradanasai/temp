package com.codingmaxima.admin.controller;

import com.codingmaxima.admin.dto.ProblemsProgressDto;
import com.codingmaxima.admin.service.ProblemsProgressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import java.util.Map;

import static com.codingmaxima.admin.constants.Constants.ROLE_STUDENT;

@RestController
@RequestMapping("/dashboard/problems")
@PreAuthorize(ROLE_STUDENT)
public class ProblemsProgressDashboardController {
    @Autowired
    private ProblemsProgressService problemsProgressService;

    @PostMapping
    public ResponseEntity<ProblemsProgressDto> addProblemProgressDetails(@RequestBody ProblemsProgressDto progressDto) {
        return ResponseEntity.ok(problemsProgressService.addProblemProgressDetails(progressDto));
    }

    @GetMapping("/{batchId}")
    public ResponseEntity<Map<String, Integer>> findroblemsLeaderBoardDetails(@PathVariable String batchId) {
        return ResponseEntity.ok(problemsProgressService.getProblemsLeaderBoardDetailsBy(batchId));
    }
}
