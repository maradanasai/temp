package com.codingmaxima.admin.mapper;

import com.codingmaxima.admin.dto.CourseDto;
import com.codingmaxima.admin.repository.entity.Course;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CourseMapper {
    CourseDto toCourseDto(Course course);
    Course fromCourseDto(CourseDto courseDto);
}
