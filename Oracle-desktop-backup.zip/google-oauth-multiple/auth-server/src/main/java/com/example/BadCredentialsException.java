package com.example;

public class BadCredentialsException extends Exception {

	public BadCredentialsException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
