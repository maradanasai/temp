package com.javachinna.service;

import com.javachinna.dto.ProductRequest;
import com.javachinna.model.Product;

public interface ProductService extends Service<Product, ProductRequest> {

}
