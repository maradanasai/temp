/**
 * 
 */
package com.javachinna.config;

/**
 * @author Chinna
 *
 */
public class AppConstants {
	public final static String SUCCESS = "success";
	public static final String ID = "ID";
}
