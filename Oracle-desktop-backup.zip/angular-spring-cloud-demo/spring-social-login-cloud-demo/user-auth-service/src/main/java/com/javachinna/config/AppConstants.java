/**
 * 
 */
package com.javachinna.config;

/**
 * @author Chinna
 *
 */
public class AppConstants {
	public static final String TOKEN_INVALID = "INVALID";
	public static final String TOKEN_EXPIRED = "EXPIRED";
	public static final String TOKEN_VALID = "VALID";
	public final static String SUCCESS = "success";
	public static final String ID = "ID";
}
