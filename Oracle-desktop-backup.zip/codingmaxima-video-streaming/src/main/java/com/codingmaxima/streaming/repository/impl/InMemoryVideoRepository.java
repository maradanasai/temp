package com.codingmaxima.streaming.repository.impl;

import com.codingmaxima.streaming.exceptions.VideoNotFoundException;
import com.codingmaxima.streaming.model.Video;
import com.codingmaxima.streaming.repository.VideoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class InMemoryVideoRepository implements VideoRepository {

    private final Map<String, Video> videoCache = new ConcurrentHashMap<>();

    @Override
    public Mono<Video> getVideoByName(String name) {
        return Mono.create(videoMonoSink -> {
            Video video = videoCache.get(name);
            if (video != null)
                videoMonoSink.success(video);
            else
                videoMonoSink.error(new VideoNotFoundException());
        });
    }

    @Override
    public Flux<Video> getAllVideos() {
        return Flux.fromIterable(videoCache.values());
    }

    @Override
    public Video addVideo(Video video) {
        return videoCache.put(video.getName(), video);
    }

    @Override
    public Video deleteVideo(String name) {
        return videoCache.remove(name);
    }

    @Override
    public Map<String, Video> getVideoDetailsCache() {
        return videoCache;
    }
}
