package com.codingmaxima.streaming.services;

import com.codingmaxima.streaming.model.Video;
import reactor.core.publisher.Flux;

public interface FileService {
    Flux<Video> getAllFiles();
}
