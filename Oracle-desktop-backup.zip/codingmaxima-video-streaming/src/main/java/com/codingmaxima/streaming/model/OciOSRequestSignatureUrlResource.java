package com.codingmaxima.streaming.model;

import com.oracle.bmc.ConfigFileReader;
import com.oracle.bmc.auth.AuthenticationDetailsProvider;
import com.oracle.bmc.auth.ConfigFileAuthenticationDetailsProvider;
import com.oracle.bmc.http.ApacheConfigurator;
import com.oracle.bmc.http.ApacheConnectorProperties;
import com.oracle.bmc.objectstorage.ObjectStorageClient;
import com.oracle.bmc.objectstorage.model.ObjectSummary;
import com.oracle.bmc.objectstorage.requests.GetObjectRequest;
import com.oracle.bmc.objectstorage.requests.ListObjectsRequest;
import org.glassfish.jersey.apache.connector.ApacheConnectionClosingStrategy;
import org.springframework.core.io.UrlResource;

import java.io.IOException;
import java.io.InputStream;
import java.net.*;


public class OciOSRequestSignatureUrlResource extends UrlResource {
    private static ObjectStorageClient client;

    static {
        String configurationFilePath = "/Users/rajeevmarrapu/rajivkumarmarrapu-oci/oci.config";
        String profile = "DEFAULT";

        try {
            final ConfigFileReader.ConfigFile configFile = ConfigFileReader.parse(configurationFilePath, profile);
            final AuthenticationDetailsProvider provider = new ConfigFileAuthenticationDetailsProvider(configFile);

            ApacheConnectorProperties properties = ApacheConnectorProperties.builder()
                    .connectionClosingStrategy(new ApacheConnectionClosingStrategy.ImmediateClosingStrategy())
                    .build();

            client = ObjectStorageClient.builder()
                    .clientConfigurator(new ApacheConfigurator.NonBuffering(properties))
                    .build(provider);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public OciOSRequestSignatureUrlResource(URI uri) throws MalformedURLException {
        super(uri);
    }

    public OciOSRequestSignatureUrlResource(String urlString) throws IOException {
        this(URI.create(urlString));
    }

    @Override
    public InputStream getInputStream() throws IOException {
        String namespaceName = "axdlioq6pjgp";
        String bucketName = "codingmaxima-std-videos";

        ListObjectsRequest listObjectsRequest = ListObjectsRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .fields("name")
                .build();

        String objectName = "InterstellarMainTheme-HansZimmer.mp4"; /*client.listObjects(listObjectsRequest)
                .getListObjects()
                .getObjects()
                .stream()
                .map(ObjectSummary::getName)
                .findFirst()
                .get();*/

        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .objectName(objectName)
                .build();

        return client.getObject(getObjectRequest).getInputStream();
    }

    @Override
    public long contentLength() throws IOException {
        String namespaceName = "axdlioq6pjgp";
        String bucketName = "codingmaxima-std-videos";
        String objectName = "InterstellarMainTheme-HansZimmer.mp4";

        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .objectName(objectName)
                .build();

        return client.getObject(getObjectRequest).getContentLength();
    }

    @Override
    public boolean isReadable() {
        String namespaceName = "axdlioq6pjgp";
        String bucketName = "codingmaxima-std-videos";
        String objectName = "InterstellarMainTheme-HansZimmer.mp4";

        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(bucketName)
                .objectName(objectName)
                .build();
        return client.getObject(getObjectRequest)
                .getContentLength() > 0;
    }

    @Override
    public boolean exists() {
        return true;
    }
}
