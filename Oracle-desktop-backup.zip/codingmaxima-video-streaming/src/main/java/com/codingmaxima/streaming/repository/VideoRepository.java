package com.codingmaxima.streaming.repository;

import com.codingmaxima.streaming.model.Video;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;

public interface VideoRepository {
    Mono<Video> getVideoByName(String name);
    Flux<Video> getAllVideos();
    Video addVideo(Video video);
    Video deleteVideo(String name);
    Map<String, Video> getVideoDetailsCache();
}
