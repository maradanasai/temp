package com.codingmaxima.streaming.config;

import com.codingmaxima.streaming.repository.VideoRepository;
import com.codingmaxima.streaming.services.FileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@Slf4j
public class Bootstrap implements CommandLineRunner {
    private final VideoRepository videoRepository;
    private final FileService fileService;

    public Bootstrap(VideoRepository videoRepository, FileService fileService) {
        this.videoRepository = videoRepository;
        this.fileService = fileService;
    }

    @Override
    public void run(String... args) {
        fileService.getAllFiles()
                .doOnNext(video -> log.debug("Video name: " + video.getName() + ", URL: " + video.getUri()))
                .map(video -> Mono.fromCallable(() -> videoRepository.addVideo(video)))
                .subscribe();
    }
}
