package com.codingmaxima.streaming.services.impl;

import com.codingmaxima.streaming.model.Video;
import com.codingmaxima.streaming.services.FileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import javax.annotation.PostConstruct;

@Service
@Slf4j
public class FileServiceImpl implements FileService {

    @Value("${codingmaxima.app.url}")
    private String codingmaximaAppUrl;

    private WebClient webClient;

    @PostConstruct
    public void init() {
        this.webClient = WebClient.builder()
                .baseUrl(codingmaximaAppUrl)
                .build();
    }

    @Override
    public Flux<Video> getAllFiles() {
        return webClient.get()
                .uri("/video/all")
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToFlux(Video.class);
    }
}
