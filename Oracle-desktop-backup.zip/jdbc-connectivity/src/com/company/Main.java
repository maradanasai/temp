package com.company;

import java.sql.*;

public class Main {

    static final String DB_URL = "jdbc:oracle:thin:@ugbu-phx-401.snphxprshared1.gbucdsint02phx.oraclevcn.com:1521:X128000D";
    static final String USER = "CFMUSER";
    static final String PASS = "CFMUSER";
    static final String QUERY = "SELECT CCBSP.SP_ID AS D1_SP_ID, NVL(REGEXP_SUBSTR(CPG.GEO_VAL, '[^ ]+', 1,1), " +
            "NVL(REGEXP_SUBSTR(CSG.GEO_VAL, '[^ ]+', 1,1), to_char(mdmsp.D1_GEO_LAT))) AS LATITUDE, NVL(REGEXP_SUBSTR(CPG.GEO_VAL, '[^ ]+', 1,2), " +
            "NVL(REGEXP_SUBSTR(CSG.GEO_VAL, '[^ ]+', 1,2), to_char(mdmsp.D1_GEO_LONG))) AS LONGITUDE FROM d1_sp mdmsp INNER JOIN d1_sp_identifier dspi " +
            "ON dspi.d1_sp_id = mdmsp.d1_sp_id INNER JOIN CI_SP CCBSP ON ccbsp.sp_id = dspi.id_value LEFT JOIN ci_sp_geo csg ON csg.sp_id = ccbsp.sp_id " +
            "AND csg.geo_type_cd = 'LAT/LONG' LEFT JOIN ci_prem_geo cpg ON cpg.prem_id = ccbsp.prem_id AND cpg.geo_type_cd = 'LAT/LONG' " +
            "WHERE dspi.sp_id_type_flg = 'D1EI' AND dspi.d1_sp_id = '420567101422'";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(QUERY);) {
            while (rs.next()) {
                System.out.println("latitude: " + rs.getString("latitude"));
                System.out.println("longitude: " + rs.getString("longitude"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
