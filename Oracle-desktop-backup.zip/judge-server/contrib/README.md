# contrib

This directory contains snippets that we use to administer judges on
[dmoj.ca](https://dmoj.ca), and that we think might be more broadly useful.
They are, however, provided with no support &mdash; please do not file bugs
against scripts you find here (we will generally accept PRs, though).

If you have a script you think would fit here, feel free to send in a PR.
