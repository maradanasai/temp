#include <cstdio>
#include <cstdlib>

using namespace std;

int main() {
  for (;;)
    ;
  return 0;
}
