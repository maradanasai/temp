#include "testlib.h"

int main(int argc, char *argv[]) {
  registerTestlibCmd(argc, argv);
  quitp(_pc(5 - 16), "");
}
