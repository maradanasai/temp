#include <cstdio>
#include <cstdlib>

using namespace std;

int main() { return (new int[512][512][512])[0][0][0]; }
