#include "header.h"

#ifdef HEADER_EXISTS
int main() { return 0; }
#endif
