#ifdef FLAG
int main() { return 0; }
#endif
