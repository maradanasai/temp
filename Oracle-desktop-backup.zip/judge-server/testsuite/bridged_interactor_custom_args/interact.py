import sys

if sys.argv[1] == "The arguments":
    raise SystemExit(0)
else:
    raise SystemExit(1)
