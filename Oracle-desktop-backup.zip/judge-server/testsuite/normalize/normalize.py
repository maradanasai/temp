def check(process_output, judge_output, judge_input, **kwargs):
   return judge_output == judge_input
