#include <machine/reg.h>
typedef struct reg ptbox_regs;
