#pragma once
#ifndef id198d0986_429f_4748_b77b_d50bbfd77289
#define id198d0986_429f_4748_b77b_d50bbfd77289

#include <sys/user.h>

typedef struct user_regs_struct ptbox_regs;

#endif
