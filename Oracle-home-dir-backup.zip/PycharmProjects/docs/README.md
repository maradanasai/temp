# DMOJ Documentation
Documentation for the [DMOJ judge](https://github.com/DMOJ/judge) system.

Access at [https://docs.dmoj.ca](https://docs.dmoj.ca)
