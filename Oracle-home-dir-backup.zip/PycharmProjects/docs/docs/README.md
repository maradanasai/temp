## DMOJ: Modern Online Judge

This documentation aims to guide you through installing your own DMOJ instance.

Feel free to reach out to us on [Slack](https://slack.dmoj.ca) if you have any
questions.
