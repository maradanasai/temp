package com.example.sociallogindemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialLoginDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
