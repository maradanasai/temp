package com.example.sociallogindemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialLoginDemoApplication {
	public static void main(String[] args) {
		SpringApplication.run(SocialLoginDemoApplication.class, args);
	}

}
