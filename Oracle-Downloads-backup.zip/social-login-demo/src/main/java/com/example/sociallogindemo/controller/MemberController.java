package com.example.sociallogindemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;

@RestController
public class MemberController {
    @Autowired
    private OAuth2AuthorizedClientRepository authorizedClientRepository;

    @GetMapping("/user")
    @PreAuthorize("hasRole('ROLE_USER')")
    public UserResponse user(Principal principal) {
        OAuth2AuthenticationToken authentication = (OAuth2AuthenticationToken) principal;
        return new UserResponse(
                authentication.getPrincipal().getAttribute("email"),
                authentication.getPrincipal().getAttribute("name"));
    }

    static class UserResponse {
        private String email;
        private String name;

        public UserResponse(String email, String name) {
            this.email = email;
            this.name = name;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public AdminResponse admin(Principal principal, HttpServletRequest request) {
        OAuth2AuthenticationToken authentication = (OAuth2AuthenticationToken) principal;
        OAuth2AuthorizedClient authorizedClient = authorizedClientRepository.loadAuthorizedClient(
                authentication.getAuthorizedClientRegistrationId(),
                authentication,
                request);
        return new AdminResponse(
                authentication.getPrincipal().getAttribute("email"),
                authentication.getPrincipal().getAttribute("name"),
                authorizedClient.getAccessToken().getTokenValue(),
                authorizedClient.getRefreshToken() == null ? "" : authorizedClient.getRefreshToken().getTokenValue()
        );
    }

    static class AdminResponse {
        private String email;
        private String name;
        private String accessToken;
        private String refreshToken;

        public AdminResponse(String email, String name, String accessToken, String refreshToken) {
            this.email = email;
            this.name = name;
            this.accessToken = accessToken;
            this.refreshToken = refreshToken;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAccessToken() {
            return accessToken;
        }

        public void setAccessToken(String accessToken) {
            this.accessToken = accessToken;
        }

        public String getRefreshToken() {
            return refreshToken;
        }

        public void setRefreshToken(String refreshToken) {
            this.refreshToken = refreshToken;
        }
    }
}
