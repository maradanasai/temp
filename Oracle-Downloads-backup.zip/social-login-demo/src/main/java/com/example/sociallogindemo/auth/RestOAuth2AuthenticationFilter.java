package com.example.sociallogindemo.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.client.authentication.OAuth2LoginAuthenticationToken;
import org.springframework.security.oauth2.client.endpoint.DefaultAuthorizationCodeTokenResponseClient;
import org.springframework.security.oauth2.client.oidc.authentication.OidcAuthorizationCodeAuthenticationProvider;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizationRequestResolver;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationExchange;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationResponse;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.annotation.PostConstruct;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.sociallogindemo.model.Member;
import com.example.sociallogindemo.repository.MemberRepository;

import java.io.IOException;
import java.util.*;

@Component
public class RestOAuth2AuthenticationFilter extends GenericFilterBean {
    private static final String contentTypeHeader = "Content-Type";
    private static final String baseUri = "/auth";
    private static final String registrationIdUriVariableName = "registrationId";
    private static final String redirectUri = "postmessage";
    private static final String nonceParameterName = "nonce";

    @Autowired
    private ClientRegistrationRepository clientRegistrationRepository;
    @Autowired
    private OAuth2AuthorizedClientRepository authorizedClientRepository;
    @Autowired
    private TokenManager tokenManager;
    @Autowired
    private MemberUserDetailsService userDetailsService;
    @Autowired
    private MemberRepository memberRepository;

    private AuthenticationManager authenticationManager;
    private DefaultOAuth2AuthorizationRequestResolver authorizationRequestResolver;
    private final AntPathRequestMatcher requestMatcher =
            new AntPathRequestMatcher(String.format("%s/{%s}", baseUri, registrationIdUriVariableName), HttpMethod.POST.name());

    @PostConstruct
    public void init() {
        authorizationRequestResolver = new DefaultOAuth2AuthorizationRequestResolver(clientRegistrationRepository, baseUri);

        DefaultAuthorizationCodeTokenResponseClient accessTokenResponseClient = new DefaultAuthorizationCodeTokenResponseClient();
        OidcUserService userService = new OidcUserService();
        OidcAuthorizationCodeAuthenticationProvider authenticationProvider = new OidcAuthorizationCodeAuthenticationProvider(accessTokenResponseClient, userService);
        authenticationManager = new ProviderManager(authenticationProvider);

        authorizationRequestResolver.setAuthorizationRequestCustomizer(oauth2AuthorizationRequestBuilder ->
                oauth2AuthorizationRequestBuilder
                        .redirectUri(redirectUri)
                        .additionalParameters(e -> e.remove(nonceParameterName))
                        .attributes(e -> e.remove(nonceParameterName)));
    }

    @Override
    public void doFilter(ServletRequest req,
                         ServletResponse res,
                         FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        if (!requireAuthentication(request)) {
            chain.doFilter(request, response);
            return;
        }

        try {
            OAuth2AuthenticationToken authentication = authenticate(request, response);
            successfulAuthentication(response, authentication);
        } catch (Exception e) {
            unsuccessfulAuthentication(response, e);
        }
    }

    private boolean requireAuthentication(HttpServletRequest request) {
        return requestMatcher.matches(request);
    }

    private OAuth2AuthenticationToken authenticate(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String code = readCode(request);
        if (Objects.isNull(code)) {
            throw new OAuth2AuthenticationException(new OAuth2Error("authentication_code_missing"));
        }
        String registrationId = requestMatcher.matcher(request).getVariables().get(registrationIdUriVariableName);
        if (Objects.isNull(registrationId)) {
            throw new OAuth2AuthenticationException(new OAuth2Error("client_registration_not_found"));
        }
        ClientRegistration clientRegistration = clientRegistrationRepository.findByRegistrationId(registrationId);
        if (Objects.isNull(clientRegistration)) {
            throw new OAuth2AuthenticationException(new OAuth2Error("client_registration_not_found"));
        }

        OAuth2AuthorizationRequest authorizationRequest = authorizationRequestResolver.resolve(request, registrationId);

        OAuth2AuthorizationResponse authorizationResponse = OAuth2AuthorizationResponse
                .success(code)
                .redirectUri(redirectUri)
                .state(authorizationRequest.getState())
                .build();

        OAuth2LoginAuthenticationToken authenticationRequest = new OAuth2LoginAuthenticationToken(clientRegistration,
                new OAuth2AuthorizationExchange(authorizationRequest, authorizationResponse));

        OAuth2LoginAuthenticationToken authenticationResult = (OAuth2LoginAuthenticationToken) authenticationManager.authenticate(authenticationRequest);

        String username = authenticationResult.getPrincipal().getAttribute("email");
        UserDetails user = loadUser(username);
        if (Objects.isNull(user)) {
            user = createUser(authenticationResult);
        }
        Collection<GrantedAuthority> authorities = mergeAuthorities(authenticationResult, user);

        OAuth2AuthenticationToken oauth2Authentication = new OAuth2AuthenticationToken(
                authenticationResult.getPrincipal(),
                authorities,
                authenticationResult.getClientRegistration().getRegistrationId());

        OAuth2AuthorizedClient authorizedClient = new OAuth2AuthorizedClient(
                authenticationResult.getClientRegistration(),
                oauth2Authentication.getName(),
                authenticationResult.getAccessToken(),
                authenticationResult.getRefreshToken());

        authorizedClientRepository.saveAuthorizedClient(authorizedClient, oauth2Authentication, request, response);

        return oauth2Authentication;
    }

    @Autowired
    private ObjectMapper objectMapper;

    private String readCode(HttpServletRequest request) throws IOException {
        Map<String, Object> authRequest = objectMapper.readValue(request.getReader(), new TypeReference<HashMap<String, Object>>() {});
        return (String) authRequest.get("code");
    }

    private UserDetails loadUser(String username) {
        try {
            return userDetailsService.loadUserByUsername(username);
        } catch (UsernameNotFoundException e) {
            return null;
        }
    }

    private UserDetails createUser(OAuth2LoginAuthenticationToken authentication) {
        Map<String, Object> attributes = authentication.getPrincipal().getAttributes();
        String username = (String) attributes.get("email");
        Member member = new Member(
                username,
                authentication.getClientRegistration().getRegistrationId(),
                (String) attributes.get("name"),
                Collections.singletonList("ROLE_USER"));
        memberRepository.save(member);

        return userDetailsService.loadUserByUsername(username);
    }

    private Collection<GrantedAuthority> mergeAuthorities(OAuth2LoginAuthenticationToken authentication, UserDetails user) {
        Set<GrantedAuthority> authorities = new HashSet<>();
        authorities.addAll(authentication.getAuthorities());
        authorities.addAll(user.getAuthorities());
        return authorities;
    }

    private void successfulAuthentication(HttpServletResponse response, OAuth2AuthenticationToken authentication) throws IOException {
        SecurityContextHolder.getContext().setAuthentication(authentication);

        String token = tokenManager.generate(authentication);
        tokenManager.set(token, authentication);

        response.addHeader(contentTypeHeader, MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().println(objectMapper.writeValueAsString(new TokenResponse(token)));
    }

    private void unsuccessfulAuthentication(HttpServletResponse response, Exception exception) throws IOException {
        SecurityContextHolder.clearContext();
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED, exception.getMessage());
    }

    private static class TokenResponse {
        private final String token;

        public TokenResponse(String token) {
            this.token = token;
        }

        public String getToken() {
            return token;
        }
    }
}
