package com.example.sociallogindemo.config;

import com.example.sociallogindemo.model.Member;
import com.example.sociallogindemo.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.boot.ApplicationRunner;

import java.util.Arrays;
import java.util.Collections;

@Configuration
public class MemberConfiguration {
    @Autowired
    private MemberRepository memberRepository;

    @Bean
    public ApplicationRunner initMembers() {
        return new ApplicationRunner() {
            @Override
            public void run(ApplicationArguments args) throws Exception {
                memberRepository.saveAll(Arrays.asList(
                        new Member("maradanasai143@gmail.com", "google", "Monika", Arrays.asList("ROLE_ADMIN", "ROLE_USER")),
                        new Member("admin@gmail.com", "google", "Jack", Collections.singletonList("ROLE_USER")),
                        new Member("peter@gmail.com", "google", "Peter", Collections.singletonList("ROLE_USER"))));
            }
        };
    }
}
