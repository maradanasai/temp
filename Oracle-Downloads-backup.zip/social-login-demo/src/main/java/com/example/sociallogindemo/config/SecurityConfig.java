package com.example.sociallogindemo.config;

import com.example.sociallogindemo.auth.RestOAuth2AccessDeniedHandler;
import com.example.sociallogindemo.auth.RestOAuth2AuthenticationEntryPoint;
import com.example.sociallogindemo.auth.RestOAuth2AuthenticationFilter;
import com.example.sociallogindemo.auth.RestOAuth2AuthorizationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private RestOAuth2AuthorizationFilter restfulOAuth2AuthorizationFilter;
    @Autowired
    private RestOAuth2AuthenticationFilter restfulOAuth2AuthenticationFilter;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()

                .addFilterBefore(restfulOAuth2AuthorizationFilter, BasicAuthenticationFilter.class)
                .addFilterBefore(restfulOAuth2AuthenticationFilter, BasicAuthenticationFilter.class)

                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)

                .and()
                .exceptionHandling()
                .authenticationEntryPoint(new RestOAuth2AuthenticationEntryPoint())
                .accessDeniedHandler(new RestOAuth2AccessDeniedHandler())

                .and()
                .authorizeRequests()
                .antMatchers("/login.html").permitAll()
                .anyRequest().authenticated();
    }
}
