package com.frontier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AopValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AopValidationApplication.class, args);
	}

}
