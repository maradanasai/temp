package com.frontier.dto;

public class ErrorDataDto {
    private final String code;
    private final String field;
    private final String message;
    private final String recordId;

    public ErrorDataDto(String code, String field, String message, String recordId) {
        this.code = code;
        this.field = field;
        this.message = message;
        this.recordId = recordId;
    }

    public String getCode() {
        return code;
    }

    public String getField() {
        return field;
    }

    public String getMessage() {
        return message;
    }

    public String getRecordId() {
        return recordId;
    }
}
