package com.frontier.exceptions;

import java.io.Serializable;
import java.util.Objects;

public class ErrorData implements Serializable {

    private static final ErrorData EMPTY = new ErrorData(null, null);

    private final String code;
    private final String field;
    private final String message;
    private final String recordId;

    public ErrorData(String field, String message, String code, String recordId) {
        this.field = field;
        this.message = message;
        this.code = code;
        this.recordId = recordId;
    }

    public ErrorData(String field, String message, String code) {
        this(field, message, code, null);
    }

    public ErrorData(String field, String message) {
        this(field, message, null, null);
    }

    public String getCode() {
        return code;
    }

    public String getField() {
        return field;
    }

    public String getMessage() {
        return message;
    }

    public String getRecordId() {
        return recordId;
    }

    public static ErrorData empty() {
        return EMPTY;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ErrorData that = (ErrorData) o;
        return Objects.equals(code, that.code) &&
                Objects.equals(field, that.field) &&
                Objects.equals(message, that.message) &&
                Objects.equals(recordId, that.recordId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, field, message, recordId);
    }

    @Override
    public String toString() {
        return "ErrorData{" +
                "code='" + code + '\'' +
                ", field='" + field + '\'' +
                ", message='" + message + '\'' +
                ", recordId='" + recordId + '\'' +
                '}';
    }
}
