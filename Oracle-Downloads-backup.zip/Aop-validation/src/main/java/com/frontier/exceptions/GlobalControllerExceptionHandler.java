package com.frontier.exceptions;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.frontier.dto.ErrorDataDto;
import com.frontier.dto.ErrorDto;
import com.frontier.dto.OverrideDataDto;

@ControllerAdvice
public class GlobalControllerExceptionHandler {

	@ExceptionHandler(value = ValidationException.class)
    @ResponseBody
    public ResponseEntity<ErrorDto> handleDetailedValidationException(ValidationException exception) {
        ErrorDto errorDto = new ErrorDto();
        errorDto.setErrors(toErrorDtoList(exception.getErrors()));
        errorDto.setOverrides(toOverrideDtoList(exception.getOverrides()));
        return new ResponseEntity<>(errorDto, HttpStatus.BAD_REQUEST);
    }
	
	private List<ErrorDataDto> toErrorDtoList(List<ErrorData> errors) {
        return errors.stream()
                .map(error -> new ErrorDataDto(error.getCode(), error.getField(), error.getMessage(), error
                        .getRecordId()))
                .collect(Collectors.toList());
    }
	
	private List<OverrideDataDto> toOverrideDtoList(List<OverrideData> overrides) {
        return overrides.stream()
                .map(override -> new OverrideDataDto(override.getCode(),
                        override.getField(),
                        override.getMessage(),
                        override.getValue(),
                        override.getRecordId()))
                .collect(Collectors.toList());
    }
}
