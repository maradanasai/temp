package com.frontier.exceptions;

import java.io.Serializable;

public class OverrideData implements Serializable {
    private final String code;
    private final String field;
    private final String message;
    private final String value;
    private final String recordId;

    public OverrideData(String field, String value) {
        this.code = null;
        this.field = field;
        this.message = null;
        this.value = value;
        this.recordId = null;
    }

    public OverrideData(String code, String field, String message, String value) {
        this.code = code;
        this.field = field;
        this.message = message;
        this.value = value;
        this.recordId = null;
    }

    public OverrideData(String code, String field, String message, String value, String recordId) {
        this.code = code;
        this.field = field;
        this.message = message;
        this.value = value;
        this.recordId = recordId;
    }

    public String getCode() {
        return code;
    }

    public String getField() {
        return field;
    }

    public String getMessage() {
        return message;
    }

    public String getValue() {
        return value;
    }

    public String getRecordId() {
        return recordId;
    }

    @Override
    public String toString() {
        return "OverrideData{" +
                "code='" + code + '\'' +
                ", field='" + field + '\'' +
                ", message='" + message + '\'' +
                ", value='" + value + '\'' +
                ", recordId='" + recordId + '\'' +
                '}';
    }
}
