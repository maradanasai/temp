package com.frontier.error.resolver;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.frontier.error.message.ErrorMessage;
import com.frontier.i18n.MessageResolver;

@Component
public class ErrorResolver {

    @Autowired
    private MessageResolver messageResolver;
    @Autowired
    private Environment env;
    private ObjectMapper objectMapper;

    @Autowired
    public ErrorResolver(MessageResolver messageResolver, Environment env, ObjectMapper objectMapper) {
        this.messageResolver = messageResolver;
        this.env = env;
        this.objectMapper = objectMapper;
    }

    public ErrorMessage getErrorMessageFromProperties(String key) {
        return getErrorMessageFromProperties(key, new Object[0]);
    }

    public ErrorMessage getErrorMessageFromProperties(String key, Object[] args) {
        String error = env.getProperty(key);
        try {
            ErrorMessage errorMessage = objectMapper.readValue(error, ErrorMessage.class);
            if (errorMessage.getKey() == null) {
                errorMessage.setKey(key);
            }
            if (errorMessage.getDescription() != null) {
                errorMessage.setDescription(messageResolver.getMessage(errorMessage.getDescription(), args));
            }
            errorMessage.setMessage(messageResolver.getMessage(errorMessage.getKey(), args));
            return errorMessage;
        } catch (IOException | NullPointerException e) {
            throw new IllegalArgumentException(e);
        }
    }
}
