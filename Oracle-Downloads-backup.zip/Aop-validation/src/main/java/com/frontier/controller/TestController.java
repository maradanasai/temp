package com.frontier.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.frontier.validation.DtoValidator;
import com.frontier.validation.NumericValidator;

@RestController
public class TestController {

	@GetMapping("/{num}")
	public String isNumeric(@DtoValidator(customValidator = NumericValidator.class) @PathVariable String num) {
		return num;
	}
}
