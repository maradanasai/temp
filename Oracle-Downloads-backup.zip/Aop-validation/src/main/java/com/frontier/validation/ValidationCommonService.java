package com.frontier.validation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.util.StringUtils;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.frontier.exceptions.OverrideData;
import com.frontier.filtering.GenericFilter;

public abstract class ValidationCommonService {
    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    @Qualifier("mvcValidator")
    private Validator defaultValidator;

    private ValidationResultAnalyser validationResultAnalyser;

    @Autowired
    public ValidationCommonService(ValidationResultAnalyser validationResultAnalyser) {
        this.validationResultAnalyser = validationResultAnalyser;
    }

    public void validate(Object object, Class<? extends Validator> validator) {
        validateDefault(object);
        if (validator != null) {
            validateCustom(object, validator);
        }
    }

    private void validateDefault(Object object) {
        List<OverrideData> overrides = new ArrayList<>();
        BindingResult bindingResult = new BeanPropertyBindingResult(
                object, StringUtils.uncapitalize(object.getClass().getSimpleName()));
        ValidationUtils.invokeValidator(defaultValidator, object, bindingResult);
        validationResultAnalyser.analyseValidationResult(bindingResult, overrides);
    }

    private void validateCustom(Object object, Class<? extends Validator> validatorClass) {
        if (DefaultValidator.class.equals(validatorClass)) {
            return;
        }

        if (object instanceof Collection) {
            Collection collection = (Collection) object;
            validateCollection(collection, validatorClass);
        } else if (object instanceof GenericFilter) {
            validateFilter((GenericFilter) object, validatorClass);
        } else {
            validateObject(object, validatorClass);
        }
    }

    private void validateCollection(Collection collection, Class<? extends Validator> validatorClass) {
        if (collection.isEmpty()) {
            return;
        }

        Object first = collection.iterator().next();
        List<OverrideData> overrides = new ArrayList<>();
        Validator validator = applicationContext.getBean(validatorClass);
        BindingResult allBindingResult = new BeanPropertyBindingResult(
                first, StringUtils.uncapitalize(first.getClass().getSimpleName()));

        for (Object object : collection) {
            BindingResult bindingResult = new BeanPropertyBindingResult(
                    object, StringUtils.uncapitalize(object.getClass().getSimpleName()));
            ValidationUtils.invokeValidator(validator, object, bindingResult, overrides);
            bindingResult.getAllErrors().forEach(allBindingResult::addError);
        }

        validationResultAnalyser.analyseValidationResult(allBindingResult, overrides);
    }

    private void validateFilter(GenericFilter filter, Class<? extends Validator> validatorClass) {
        BindingResult bindingResult = new BeanPropertyBindingResult(
                filter.getFilteringFields(),
                StringUtils.uncapitalize(filter.getFilteringFields().getClass().getSimpleName()));
        validateCommon(filter, validatorClass, bindingResult);
    }

    private void validateObject(Object object, Class<? extends Validator> validatorClass) {
        BindingResult bindingResult = new BeanPropertyBindingResult(
                object, StringUtils.uncapitalize(object.getClass().getSimpleName()));
        validateCommon(object, validatorClass, bindingResult);
    }

    private void validateCommon(Object object,
                                Class<? extends Validator> validatorClass,
                                BindingResult bindingResult) {
        List<OverrideData> overrides = new ArrayList<>();
        Validator validator = applicationContext.getBean(validatorClass);
        ValidationUtils.invokeValidator(validator, object, bindingResult, overrides);
        validationResultAnalyser.analyseValidationResult(bindingResult, overrides);
    }
}
