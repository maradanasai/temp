package com.frontier.validation;

import com.frontier.exceptions.ValidationException;
import com.frontier.i18n.MessageResolver;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class NumericValidator implements Validator {

    private static final String ERROR_FIELD_REQUIRES_NUMERIC_CHARACTERS = "error.field.requires.numeric.characters";

    @Autowired
    private MessageResolver messageResolver;

    @Override
    public boolean supports(Class<?> clazz) {
        return String.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        if (!StringUtils.isNumeric((String) target)) {
            throw new ValidationException(messageResolver.getMessage(ERROR_FIELD_REQUIRES_NUMERIC_CHARACTERS));
        }
    }
}
