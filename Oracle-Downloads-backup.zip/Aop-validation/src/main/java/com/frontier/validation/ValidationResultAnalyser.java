package com.frontier.validation;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import com.frontier.error.message.ErrorMessage;
import com.frontier.error.resolver.ErrorResolver;
import com.frontier.exceptions.ErrorData;
import com.frontier.exceptions.OverrideData;
import com.frontier.exceptions.ValidationException;

@Component
@Qualifier("validationResultAnalyser")
public class ValidationResultAnalyser {

    @Autowired
    private ErrorResolver errorResolver;

    public void analyseValidationResult(Errors bindingResult, List<OverrideData> overrides) {
        List<ErrorData> errors = bindingResult.getFieldErrors()
                .stream()
                .map(this::buildErrorData)
                .collect(Collectors.toList());

        errors.addAll(bindingResult.getGlobalErrors()
                .stream()
                .map(this::buildErrorData)
                .collect(Collectors.toList()));

        if (!errors.isEmpty() || !overrides.isEmpty()) {
            throw new ValidationException(errors, overrides);
        }
    }

    protected ErrorData buildErrorData(FieldError error) {
        ErrorMessage message = errorMessage(error.getDefaultMessage(), prepareArguments(error));

        return new ErrorData(error.getField(), textFrom(message),
                codeFrom(message), error.getCode());
    }

    protected ErrorData buildErrorData(ObjectError error) {
        ErrorMessage message = errorMessage(error.getDefaultMessage(), error.getArguments());

        return new ErrorData(null, textFrom(message),
                codeFrom(message), error.getCode());
    }

    protected Object[] prepareArguments(FieldError fieldError) {
        Object[] args = fieldError.getArguments();
        if (args == null) {
            Object value = fieldError.getRejectedValue();
            if (value == null) {
                value = "";
            }
            args = new Object[]{value};
        }
        return args;
    }

    protected ErrorMessage errorMessage(String key, Object[] args) {
        ErrorMessage result = null;
        if (key != null) {
            result = errorResolver.getErrorMessageFromProperties(
                    key, Optional.ofNullable(args).orElse(new Object[]{}));
        }
        return result;
    }

    protected String textFrom(ErrorMessage errorMessage) {
        return Optional.ofNullable(errorMessage).map(ErrorMessage::getMessage).orElse(null);
    }

    protected String codeFrom(ErrorMessage errorMessage) {
        return Optional.ofNullable(errorMessage).map(ErrorMessage::getCode).orElse(null);
    }

}
