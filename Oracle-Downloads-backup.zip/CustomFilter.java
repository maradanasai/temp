package com.rohit.cloudgateway.config;

import com.rohit.cloudgateway.models.User;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component
public class CustomFilter extends AbstractGatewayFilterFactory<CustomFilter.Config> {
    public CustomFilter() {
        super(Config.class);
    }

    List<User> loggedInUsers;

    @PostConstruct
    public void postCreation() {
        Date date = new Date();
        loggedInUsers = Arrays.asList
                (
                        new User(1, "user1", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c", date),
                        new User(2, "user2", "token2", date),
                        new User(1, "user3", "token3", date)
                );
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            System.out.println("First pre filter" + exchange.getRequest());
            if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
                throw new RuntimeException("Missing Auth header.");
            }
            String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
            String[] split = authHeader.split(" ");

            if (split.length != 2 || !"Bearer".equals(split[0])) {
                throw new RuntimeException("Incorrect auth structure.");
            }
            //do further validation with JWT token (split[1]) and throw the exception accordingly or send the request further.
            String jwtToken = split[1];
            Optional<User> optionalUser = loggedInUsers.stream().filter(user -> user.getToken().equals(jwtToken)).findAny();
            if (optionalUser.isPresent()) {
                throw new RuntimeException("User already exists");
            }
            return chain.filter(exchange).then(Mono.fromRunnable(() -> {
                System.out.println("First post filter");
            }));
        };


    }

    public static class Config {
        // Put the configuration properties
    }
}