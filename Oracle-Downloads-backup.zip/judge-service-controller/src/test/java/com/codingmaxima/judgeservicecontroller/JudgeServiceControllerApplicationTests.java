package com.codingmaxima.judgeservicecontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JudgeServiceControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
