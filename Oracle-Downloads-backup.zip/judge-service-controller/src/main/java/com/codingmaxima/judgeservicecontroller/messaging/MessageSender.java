package com.codingmaxima.judgeservicecontroller.messaging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.Map;
import java.util.UUID;

import static com.codingmaxima.judgeservicecontroller.constants.LanguageResourceLimit.*;
import static com.codingmaxima.judgeservicecontroller.constants.Constants.*;

@Component
public class MessageSender {
    private static final Logger LOG = LoggerFactory.getLogger(MessageSender.class);

    @Autowired
    private JmsTemplate jmsTemplate;

    @Autowired
    private ResponseEventsDispatcher eventsDispatcher;

    public SseEmitter sendMessage(Map<String, Object> submissionRequest) {
        String submissionId = UUID.randomUUID().toString();
        submissionRequest.put(JUDGE_SUBMISSION_ID_FIELD, submissionId);
        submissionRequest.put(JUDGE_TIME_LIMIT_FIELD, JUDGE_LANGUAGE_RESOURCE_LIMIT.get(submissionRequest.get(JUDGE_LANGUAGE_ID_FIELD)).timeLimit());
        submissionRequest.put(JUDGE_SPACE_LIMIT_FIELD, JUDGE_LANGUAGE_RESOURCE_LIMIT.get(submissionRequest.get(JUDGE_LANGUAGE_ID_FIELD)).spaceLimit());

        jmsTemplate.convertAndSend(submissionRequest);
        LOG.info("Request sent: " + submissionRequest.get(JUDGE_SUBMISSION_ID_FIELD));
        eventsDispatcher.addResponseEventFor(submissionId);
        return eventsDispatcher.findResponseEventEmitterFor(submissionId);
    }
}
