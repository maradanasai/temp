package com.codingmaxima.judgeservicecontroller.controller;


import com.codingmaxima.judgeservicecontroller.service.HealthCheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/")
public class HealthCheckController {
    @Autowired
    private HealthCheckService healthCheckService;

    @GetMapping
    public List<Map<String, Object>> health() {
        return healthCheckService.findAllJudgesHealth();
    }

    @GetMapping("/ping")
    public String ping() {
        return "pong!";
    }
}
