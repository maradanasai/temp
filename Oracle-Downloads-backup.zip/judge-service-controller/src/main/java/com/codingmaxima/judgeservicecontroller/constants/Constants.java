package com.codingmaxima.judgeservicecontroller.constants;

/*
* Note: If you change any field name, make sure you should change the names in the
* judge & codingmaxima backend apps too.
 */
public class Constants {
    public static final String RESULT_SUBMISSION_ID = "submission_id";
    public static final String RESULT_PROBLEM_ID = "problem_id";
    public static final String RESULT_TESTCASE_NUMBER = "testcase_number";
    public static final String RESULT_INPUT = "input";
    public static final String RESULT_EXPECTED_OUTPUT = "expected_output";
    public static final String RESULT_ACTUAL_OUTPUT = "actual_output";
    public static final String RESULT_STATUS = "status";
    public static final String RESULT_CPU_TIME = "cpu_time";
    public static final String RESULT_MEMORY = "memory";
    public static final String RESULT_COMPILE = "compile";
    public static final String RESULT_ERROR = "error";
    public static final String RESULT_DONE = "done";

    public static final String HEART_BEAT_EVENT = "heartbeat";
    public static final String JUDGE_ID = "judge_id";
    public static final String PROCESS_CPU_LOAD = "process_cpu_load";
    public static final String SYSTEM_CPU_LOAD = "system_cpu_load";
    public static final String SYSTEM_AVG_LOAD = "system_avg_load";
    public static final String FREE_MEMORY = "free_memory";
    public static final String TOTAL_MEMORY = "total_memory";

    public static final String JUDGE_SUBMISSION_ID_FIELD = "submission_id";
    public static final String JUDGE_TIME_LIMIT_FIELD = "time_limit";
    public static final String JUDGE_SPACE_LIMIT_FIELD = "space_limit";
    public static final String JUDGE_LANGUAGE_ID_FIELD = "language_id";
    public static final String JUDGE_PROBLEM_ID_FIELD = "problem_id";
    public static final String JUDGE_SOLUTION_CODE_FIELD = "solution_code";
    public static final String TEST_CASES_PER_PROB = "test_cases";
}
