package com.codingmaxima.judgeservicecontroller.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class HealthCheckService {
    private static final Logger LOG = LoggerFactory.getLogger(HealthCheckService.class);

    private static final String JUDGE_ID = "judge_id";
    private static final String HEART_BEAT_EVENT = "recent_heartbeat_at";
    private static final String JUDGE_STATUS = "judge_status";
    private static final int HEALTH_CHECK_FREQUENCY_IN_MINS = 20;

    private final Map<String, Map<String, Object>> allJudges = new ConcurrentHashMap<>();

    public List<Map<String, Object>> findAllJudgesHealth() {
        List<Map<String, Object>> result = allJudges
                .values()
                .stream()
                .peek(e -> {
                    String timestamp = (String) e.get(HEART_BEAT_EVENT);
                    ZonedDateTime lastHealthCheckAtTime = ZonedDateTime.parse(timestamp);
                    ZonedDateTime currentTime = Instant.now().atZone(ZoneId.of("Asia/Kolkata"));
                    int diff = (int) Math.abs(ChronoUnit.MINUTES.between(lastHealthCheckAtTime, currentTime));
                    if (diff >= HEALTH_CHECK_FREQUENCY_IN_MINS + 1) {
                        e.put(JUDGE_STATUS, "Offline");
                    }
                })
                .collect(Collectors.toList());

        result.add(Collections.singletonMap("server_datetime", Instant.now().atZone(ZoneId.of("Asia/Kolkata")).toString()));
        return result;
    }

    public void updateHeartBeatEvent(final Map<String, Object> event) {
        allJudges.put((String) event.get(JUDGE_ID), event);
        LOG.info("Got heart beat event for Judge id: " + event.get(JUDGE_ID));
    }

    /*private ScheduledExecutorService executorService;

    @PostConstruct
    public void judgesStatusUpdator() {
        executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.scheduleAtFixedRate(() -> {
                    for (Map<String, Object> e : allJudges.values()) {
                        String timestamp = (String) e.get(HEART_BEAT_EVENT);
                        ZonedDateTime lastHealthCheckAtTime = ZonedDateTime.parse(timestamp);
                        ZonedDateTime currentTime = Instant.now().atZone(ZoneId.of("Asia/Kolkata"));
                        int diff = (int) Math.abs(ChronoUnit.MINUTES.between(lastHealthCheckAtTime, currentTime));
                        if (diff >= HEALTH_CHECK_FREQUENCY_IN_MINS + 2) {
                            e.put("judge_status", "Offline");
                        }
                    }
                    LOG.info("Performed judges status updation");
                }, 0, HEALTH_CHECK_FREQUENCY_IN_MINS, TimeUnit.SECONDS);
    }

    @PreDestroy
    public void cleanUp() {
        LOG.info("Initiate Shutdown of judges health check ops ...");
        if (Objects.nonNull(executorService)) executorService.shutdown();
    }*/
}
