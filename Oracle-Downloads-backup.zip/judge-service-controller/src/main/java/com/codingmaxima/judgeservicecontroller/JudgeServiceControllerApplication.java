package com.codingmaxima.judgeservicecontroller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JudgeServiceControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JudgeServiceControllerApplication.class, args);
	}

}
