package com.codingmaxima.judgeservicecontroller.controller;


import com.codingmaxima.judgeservicecontroller.messaging.MessageSender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.Map;

@RestController
@RequestMapping(value = "/submission")
public class SubmissionController {
    @Autowired
    private MessageSender messageSender;

    @PostMapping
    public SseEmitter submit(@RequestBody Map<String, Object> submissionRequest) {
        return messageSender.sendMessage(submissionRequest);
    }
}
