package com.codingmaxima.judgeservicecontroller.messaging;

import com.codingmaxima.judgeservicecontroller.service.HealthCheckService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.codingmaxima.judgeservicecontroller.constants.Constants.*;

public class MessageReceiver implements MessageListener {
    private static final Logger LOG = LoggerFactory.getLogger(MessageReceiver.class);

    @Autowired
    private ResponseEventsDispatcher eventsDispatcher;

    @Autowired
    private HealthCheckService healthCheckService;

    @Override
    public void onMessage(Message message) {
        if (message instanceof MapMessage) {
            MapMessage result = (MapMessage) message;
            try {
                SseEmitter responseEmitter = null;
                if (Objects.nonNull(result.getString(RESULT_SUBMISSION_ID))) {
                    responseEmitter = eventsDispatcher.findResponseEventEmitterFor(result.getString(RESULT_SUBMISSION_ID));
                }
                if (Objects.nonNull(result.getString(RESULT_COMPILE))) {
                    Map<String, String> response = new HashMap<>(4);
                    response.put(RESULT_SUBMISSION_ID, result.getString(RESULT_SUBMISSION_ID));
                    response.put(RESULT_COMPILE, result.getString(RESULT_COMPILE));
                    responseEmitter.send(response);
                    if (!response.get(RESULT_COMPILE).equalsIgnoreCase("compiled successfully")) { // TODO: check based on status flag
                        responseEmitter.complete();
                    }
                } else if (Objects.nonNull(result.getString(RESULT_ERROR)) && result.getString(RESULT_ERROR).length() > 2) {
                    Map<String, String> response = new HashMap<>(4);
                    response.put(RESULT_SUBMISSION_ID, result.getString(RESULT_SUBMISSION_ID));
                    response.put(RESULT_ERROR, result.getString(RESULT_ERROR));
                    responseEmitter.send(response);
                    responseEmitter.complete();
                } else if (Objects.nonNull(result.getString(RESULT_DONE))) {
                    Map<String, String> response = new HashMap<>(4);
                    response.put(RESULT_SUBMISSION_ID, result.getString(RESULT_SUBMISSION_ID));
                    response.put(RESULT_DONE, result.getString(RESULT_DONE));
                    responseEmitter.send(response);
                    responseEmitter.complete();
                    eventsDispatcher.removeResponseEventEmitter(result.getString(RESULT_SUBMISSION_ID));
                    LOG.info("Submission request completed for id: {}", result.getString(RESULT_SUBMISSION_ID));
                } else if (Objects.nonNull(result.getString(HEART_BEAT_EVENT))) {
                    Map<String, Object> map = new HashMap<>();
                    map.put(JUDGE_ID, result.getString(JUDGE_ID));
                    map.put("recent_" + HEART_BEAT_EVENT + "_at", result.getString(HEART_BEAT_EVENT));
                    map.put(PROCESS_CPU_LOAD, result.getString(PROCESS_CPU_LOAD));
                    map.put(SYSTEM_CPU_LOAD, result.getString(SYSTEM_CPU_LOAD));
                    map.put(SYSTEM_AVG_LOAD, result.getString(SYSTEM_AVG_LOAD));
                    map.put(FREE_MEMORY, result.getString(FREE_MEMORY));
                    map.put(TOTAL_MEMORY, result.getString(TOTAL_MEMORY));
                    map.put("judge_status", "Online");
                    healthCheckService.updateHeartBeatEvent(map);
                } else {
                    Map<String, Object> response = new HashMap<>();
                    response.put(RESULT_SUBMISSION_ID, result.getString(RESULT_SUBMISSION_ID));
                    response.put(RESULT_PROBLEM_ID, result.getString(RESULT_PROBLEM_ID));
                    response.put(RESULT_TESTCASE_NUMBER, result.getInt(RESULT_TESTCASE_NUMBER));
                    response.put(RESULT_INPUT, result.getString(RESULT_INPUT));
                    response.put(RESULT_EXPECTED_OUTPUT, result.getString(RESULT_EXPECTED_OUTPUT));
                    response.put(RESULT_ACTUAL_OUTPUT, result.getString(RESULT_ACTUAL_OUTPUT));
                    response.put(RESULT_STATUS, result.getString(RESULT_STATUS));
                    response.put(RESULT_CPU_TIME, result.getInt(RESULT_CPU_TIME));
                    response.put(RESULT_MEMORY, result.getInt(RESULT_MEMORY));
                    try {
                        responseEmitter.send(response);
                    } catch (Exception e) {
                        LOG.info(response.toString());
                        LOG.error("Error sending testcase realtime event: ", e);
                    }
                }
            } catch (IOException | JMSException | RuntimeException e) {
                LOG.error("Error receiving response event: ", e);
            }
        } else {
            LOG.error("Unsupported message type received: " + message.getClass().getName());
        }
    }
}
