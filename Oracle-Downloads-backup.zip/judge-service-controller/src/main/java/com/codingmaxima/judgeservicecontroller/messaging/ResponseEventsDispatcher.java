package com.codingmaxima.judgeservicecontroller.messaging;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class ResponseEventsDispatcher {
    private static final long TOTAL_RESPONSE_TIMEOUT = 2 * 60_000;
    private final Map<String, SseEmitter> responseEventsMap = new ConcurrentHashMap<>();

    public void addResponseEventFor(String submissionId) {
        responseEventsMap.put(submissionId, new SseEmitter(TOTAL_RESPONSE_TIMEOUT));
    }

    public void removeResponseEventEmitter(String submissionId) {
        responseEventsMap.remove(submissionId);
    }

    public SseEmitter findResponseEventEmitterFor(String submissionId) {
        if (!responseEventsMap.containsKey(submissionId)) {
            throw new RuntimeException("Incorrect submission id: " + submissionId);
        }
        return responseEventsMap.get(submissionId);
    }
}
