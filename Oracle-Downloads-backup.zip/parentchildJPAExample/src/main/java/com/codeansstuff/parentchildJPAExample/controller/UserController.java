package com.codeansstuff.parentchildJPAExample.controller;

import com.codeansstuff.parentchildJPAExample.dtos.UserDto;
import com.codeansstuff.parentchildJPAExample.entity.Course;
import com.codeansstuff.parentchildJPAExample.entity.User;
import com.codeansstuff.parentchildJPAExample.repositories.CourseRepository;
import com.codeansstuff.parentchildJPAExample.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CourseRepository courseRepository;

    @PostMapping
    public User addUser(@RequestBody UserDto userDto) {
        User user = new User();
        user.setId(userDto.getId());
        user.setName(userDto.getName());
        user.setRole(userDto.getRole());

        List<Course> subscribedCourses = userDto.getSubscribedCourseIds()
                .stream()
                .map(courseId -> courseRepository.findById(courseId).get())
                .collect(Collectors.toList());
        user.setSubscribedCourses(subscribedCourses);

        return userRepository.save(user);
    }

    @PutMapping
    public User updateUser(@RequestBody UserDto userDto) {
        User user = userRepository.findById(userDto.getId()).get();
        user.setName(userDto.getName());
        user.setRole(userDto.getRole());

        Set<Course> subscribedCourses = userDto.getSubscribedCourseIds()
                .stream()
                .map(courseId -> courseRepository.findById(courseId).get())
                .collect(Collectors.toSet());
        user.getSubscribedCourses().addAll(subscribedCourses);

        return userRepository.save(user);
    }

    @GetMapping
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @PostMapping("/course")
    public Course addCourse(@RequestBody Course course) {
        return courseRepository.save(course);
    }

    @PutMapping("/course")
    public Course updateCourse(@RequestBody Course course) {
        return courseRepository.save(course);
    }

    @GetMapping("/course")
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }
}
