package com.codeansstuff.parentchildJPAExample.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Topic {
    @Id
    private Integer id;

    private String name;

    @Column(name = "course_id_fk")
    private Integer courseId;
}
