package com.codeansstuff.parentchildJPAExample.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;


@Entity
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class User {
    @Id
    @EqualsAndHashCode.Include
    private String id;

    private String name;

    private String role = "STUDENT";

    @ManyToMany(cascade = CascadeType.ALL)
    private List<Course> subscribedCourses;
}
