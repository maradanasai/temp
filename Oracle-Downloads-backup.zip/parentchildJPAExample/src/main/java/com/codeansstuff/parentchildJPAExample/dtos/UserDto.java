package com.codeansstuff.parentchildJPAExample.dtos;


import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
public class UserDto {
    private String id;

    private String name;

    private String role;

    private Set<Integer> subscribedCourseIds;
}
