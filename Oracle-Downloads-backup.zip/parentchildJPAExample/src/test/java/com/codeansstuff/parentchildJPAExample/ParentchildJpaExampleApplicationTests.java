package com.codeansstuff.parentchildJPAExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParentchildJpaExampleApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
