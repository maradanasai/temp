package com.example.ssedemo;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/")
public class SseController {

    private static Map<Long, SseEmitter> sseEmitters = new Hashtable<>();

    @GetMapping("/{id}")
    public SseEmitter sseEmitterDemo(@PathVariable Long id) throws IOException {
        SseEmitter sseEmitter = new SseEmitter(60000L);
        sseEmitters.put(id, sseEmitter);
        sseEmitter.send("Established");
        return sseEmitter;
    }

    @PostMapping("/{id}")
    public void test(@PathVariable Long id) {
        new Thread(() -> {
            SseEmitter sseEmitter = sseEmitters.get(id);
            for (int i = 1; i <= 10; i++) {
                try {
                    sseEmitter.send("message: " + i + ", from: " + id);
                    Thread.sleep(2000);
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
            sseEmitter.complete();
        }).start();
    }
}
