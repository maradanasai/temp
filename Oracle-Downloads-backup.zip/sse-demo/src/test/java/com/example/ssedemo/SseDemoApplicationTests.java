package com.example.ssedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SseDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
