package com.example.customgatewaysociallogindemo;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.crypto.SecretKey;
import java.util.Date;

@SpringBootTest
class CustomGatewaySocialLoginDemoApplicationTests {

	private static final String claimAuthorities = "authorities";
	private static final String claimName = "name";
	private static final String claimEmail = "email";
	private static final String secret = "qsbWaaBHBN/I7FYOrev4yQFJm60sgZkWIEDlGtsRl7El/k+DbUmg8nmWiVvEfhZ91Y67Sc6Ifobi05b/XDwBy4kXUcKTitNqocy7rQ9Z3kMipYjbL3WZUJU2luigIRxhTVNw8FXdT5q56VfY0LcQv3mEp6iFm1JG43WyvGFV3hCkhLPBJV0TWnEi69CfqbUMAIjmymhGjcbqEK8Wt10bbfxkM5uar3tpyqzp3Q==";
	private final SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(secret));

	@Test
	public void generateJWTtoken() {
		String subject = "rajivkumarmarrapu@gmail.com";
		String name = "Rajeev Marrapu";
		String email = "rajivkumarmarrapu@gmail.com";
		String authorities = "ROLE_STUDENT";
		Date expiration = new Date(System.currentTimeMillis() + (60 * 60 * 1000));
		String token = Jwts.builder()
				.setSubject(subject)
				.claim(claimAuthorities, authorities)
				.claim(claimName, name)
				.claim(claimEmail, email)
				.signWith(key, SignatureAlgorithm.HS512)
				.setExpiration(expiration)
				.compact();

		System.out.println("AUTH token:" + token);
	}

}
