package com.example.customgatewaysociallogindemo.auth;


import com.example.customgatewaysociallogindemo.model.Member;
import com.example.customgatewaysociallogindemo.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Objects;
import java.util.stream.Collectors;

@Component
public class CustomUserDetailsService implements ReactiveUserDetailsService {
    @Autowired
    private MemberRepository userRepository;

    @Override
    public Mono<UserDetails> findByUsername(String username) throws UsernameNotFoundException {
        Member user = userRepository.findByUsername(username);
        if (Objects.isNull(user)) {
            throw new UsernameNotFoundException("User: " + username + " not found");
        }
        return Mono.just(new User(username, "", user.getAuthorities()
                .stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList())));
    }
}