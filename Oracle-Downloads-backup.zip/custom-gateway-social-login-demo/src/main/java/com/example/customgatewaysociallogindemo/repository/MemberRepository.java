package com.example.customgatewaysociallogindemo.repository;


import com.example.customgatewaysociallogindemo.model.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface MemberRepository extends JpaRepository<Member, Long> {
    @Query("SELECT m FROM Member m JOIN FETCH m.authorities WHERE m.username = (:username)")
    Member findByUsername(String username);
}
