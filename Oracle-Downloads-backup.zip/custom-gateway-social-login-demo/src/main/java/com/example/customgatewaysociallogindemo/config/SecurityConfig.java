package com.example.customgatewaysociallogindemo.config;

import com.example.customgatewaysociallogindemo.auth.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.oauth2.client.oidc.web.server.logout.OidcClientInitiatedServerLogoutSuccessHandler;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.authentication.logout.*;
import org.springframework.security.web.server.context.NoOpServerSecurityContextRepository;

@Configuration
@EnableWebFluxSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {
    @Autowired
    private RestOAuth2AuthorizationFilter restfulOAuth2AuthorizationFilter;
    @Autowired
    private RestOAuth2AuthenticationFilter restfulOAuth2AuthenticationFilter;
    @Autowired
    private TokenManager tokenManager;

    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        http
                .csrf().disable()

                .addFilterBefore(restfulOAuth2AuthorizationFilter, SecurityWebFiltersOrder.AUTHENTICATION)
                .addFilterBefore(restfulOAuth2AuthenticationFilter, SecurityWebFiltersOrder.AUTHENTICATION)

                .securityContextRepository(NoOpServerSecurityContextRepository.getInstance())
                //.sessionManagement()
                //.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                //.and()
                .exceptionHandling()
                    .authenticationEntryPoint(new RestOAuth2AuthenticationEntryPoint())
                    .accessDeniedHandler(new RestOAuth2AccessDeniedHandler())

                .and()
                    .authorizeExchange()
                        .pathMatchers("/login.html").permitAll()
                        //.pathMatchers("/login.html", "/favicon.ico").permitAll()
                    .anyExchange()
                        .authenticated();
                /*.and()
                    .logout(logout -> logout
                        .logoutHandler(logoutHandler())
                        .logoutSuccessHandler(oidcLogoutSuccessHandler()));*/

        return http.build();
    }

    /*@Autowired
    private ReactiveClientRegistrationRepository clientRegistrationRepository;

    private ServerLogoutSuccessHandler oidcLogoutSuccessHandler() {
        OidcClientInitiatedServerLogoutSuccessHandler oidcLogoutSuccessHandler =
                new OidcClientInitiatedServerLogoutSuccessHandler(clientRegistrationRepository);

        // Sets the location that the End-User's User Agent will be redirected to
        // after the logout has been performed at the Provider
        oidcLogoutSuccessHandler.setPostLogoutRedirectUri("{baseUrl}");

        return oidcLogoutSuccessHandler;
    }

    private ServerLogoutHandler logoutHandler() {
        return new DelegatingServerLogoutHandler(new WebSessionServerLogoutHandler(), new SecurityContextServerLogoutHandler());
    }*/

    private ServerLogoutHandler performLogout() {
        return (exchange, authentication) -> {
            return null;
        };
    }
}
