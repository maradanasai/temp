package com.example.customgatewaysociallogindemo.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;


@Component
public class RestOAuth2AuthorizationFilter implements WebFilter {
    private static final String authenticationHeader = "Authorization";
    private static final String authenticationScheme = "Bearer";

    @Autowired
    private TokenManager tokenManager;

    private String extractToken(ServerHttpRequest request) {
        String bearerToken = request.getHeaders().getFirst(authenticationHeader);
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith(authenticationScheme + " ")) {
            return bearerToken.substring(authenticationScheme.length() + 1);
        }
        return null;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String token = extractToken(exchange.getRequest());
        if (StringUtils.hasText(token)) {
            OAuth2AuthenticationToken authentication = tokenManager.get(token);
            if (authentication != null) {
                ReactiveSecurityContextHolder.withAuthentication(authentication);
            }
        }
        return chain.filter(exchange);
    }
}
