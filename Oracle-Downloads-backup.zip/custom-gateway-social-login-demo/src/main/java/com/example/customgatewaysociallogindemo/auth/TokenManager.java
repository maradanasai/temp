package com.example.customgatewaysociallogindemo.auth;

import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.crypto.SecretKey;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class TokenManager {
    private static final String claimAuthorities = "authorities";
    private static final String claimName = "name";
    private static final String claimEmail = "email";
    private static final String secret = "qsbWaaBHBN/I7FYOrev4yQFJm60sgZkWIEDlGtsRl7El/k+DbUmg8nmWiVvEfhZ91Y67Sc6Ifobi05b/XDwBy4kXUcKTitNqocy7rQ9Z3kMipYjbL3WZUJU2luigIRxhTVNw8FXdT5q56VfY0LcQv3mEp6iFm1JG43WyvGFV3hCkhLPBJV0TWnEi69CfqbUMAIjmymhGjcbqEK8Wt10bbfxkM5uar3tpyqzp3Q==";
    private final SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(secret));

    @Autowired
    private CacheManager cacheManager;

    private Cache cache;

    @PostConstruct
    public void init() {
        this.cache = cacheManager.getCache("tokenManager");
    }

    String generate(OAuth2AuthenticationToken authentication) {
        String subject = authentication.getName();
        String name = authentication.getPrincipal().getAttribute("name");
        String email = authentication.getPrincipal().getAttribute("email");
        String authorities = !authentication.getAuthorities().isEmpty() ?
                authentication.getAuthorities()
                        .stream()
                        .map(GrantedAuthority::getAuthority)
                        .collect(Collectors.joining(", ")) : "";
        Date expiration = new Date(System.currentTimeMillis() + (60 * 60 * 1000));
        return Jwts.builder()
                .setSubject(subject)
                .claim(claimAuthorities, authorities)
                .claim(claimName, name)
                .claim(claimEmail, email)
                .signWith(key, SignatureAlgorithm.HS512)
                .setExpiration(expiration)
                .compact();
    }

    public OAuth2AuthenticationToken get(String token) {
        if (validate(token)) {
            OAuth2AuthenticationToken authentication = (OAuth2AuthenticationToken) cache.get(token).get();
            return authentication;
        } else {
            cache.evict(token);
            return null;
        }
    }

    public void set(String token, OAuth2AuthenticationToken authentication) {
        cache.put(token, authentication);
    }

    private Boolean validate(String token) {
        try {
            JwtParser jwtParser = Jwts.parserBuilder().setSigningKey(key).build();
            jwtParser.parse(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}