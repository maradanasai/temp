package com.example.customgatewaysociallogindemo.auth;

import com.example.customgatewaysociallogindemo.model.Member;
import com.example.customgatewaysociallogindemo.repository.MemberRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.client.authentication.OAuth2LoginAuthenticationToken;
import org.springframework.security.oauth2.client.endpoint.DefaultAuthorizationCodeTokenResponseClient;
import org.springframework.security.oauth2.client.oidc.authentication.OidcAuthorizationCodeAuthenticationProvider;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.server.DefaultServerOAuth2AuthorizationRequestResolver;
import org.springframework.security.oauth2.client.web.server.ServerOAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationExchange;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationResponse;
import org.springframework.security.web.server.util.matcher.PathPatternParserServerWebExchangeMatcher;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import org.springframework.web.util.pattern.PathPattern;
import org.springframework.web.util.pattern.PathPatternParser;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;


@Component
public class RestOAuth2AuthenticationFilter implements WebFilter {
    private static final String contentTypeHeader = "Content-Type";
    private static final String baseUri = "/auth";
    private static final String registrationIdUriVariableName = "registrationId";
    private static final String redirectUri = "postmessage";
    private static final String nonceParameterName = "nonce";

    @Autowired
    private ReactiveClientRegistrationRepository clientRegistrationRepository;
    @Autowired
    private ServerOAuth2AuthorizedClientRepository authorizedClientRepository;
    @Autowired
    private TokenManager tokenManager;
    @Autowired
    private CustomUserDetailsService userDetailsService;
    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private ObjectMapper objectMapper;

    private AuthenticationManager authenticationManager;
    private DefaultServerOAuth2AuthorizationRequestResolver authorizationRequestResolver;
    private final PathPattern requestMatcher = new PathPatternParser()
            .parse(String.format("%s/{%s}", baseUri, registrationIdUriVariableName));

    @PostConstruct
    public void init() {
        authorizationRequestResolver = new DefaultServerOAuth2AuthorizationRequestResolver(
                clientRegistrationRepository, new PathPatternParserServerWebExchangeMatcher(baseUri));
        DefaultAuthorizationCodeTokenResponseClient accessTokenResponseClient = new DefaultAuthorizationCodeTokenResponseClient();
        OidcUserService userService = new OidcUserService();
        OidcAuthorizationCodeAuthenticationProvider authenticationProvider = new OidcAuthorizationCodeAuthenticationProvider(accessTokenResponseClient, userService);
        authenticationManager = new ProviderManager(authenticationProvider);

        authorizationRequestResolver.setAuthorizationRequestCustomizer(oauth2AuthorizationRequestBuilder ->
                oauth2AuthorizationRequestBuilder
                        .redirectUri(redirectUri)
                        .additionalParameters(e -> e.remove(nonceParameterName))
                        .attributes(e -> e.remove(nonceParameterName)));
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        if (!requireAuthentication(exchange.getRequest())) {
            return chain.filter(exchange);
        }

        try {
            authenticate(exchange);
        } catch (Exception e) {
            unsuccessfulAuthentication(exchange, e);
        }
        return chain.filter(exchange);
    }

    private boolean requireAuthentication(ServerHttpRequest request) {
        return request.getMethod() == HttpMethod.POST && requestMatcher.matches(request.getPath());
    }

    private void authenticate(ServerWebExchange exchange) throws IOException {
        exchange.getRequest().getBody()
                .flatMap(dataBuffer -> {
                    byte[] bytes = new byte[dataBuffer.readableByteCount()];
                    dataBuffer.read(bytes);
                    DataBufferUtils.release(dataBuffer);
                    return Mono.just(bytes);
                })
                .subscribe(bodyStr -> {
                    Map<String, String> authRequest = fromByteArrayJson(bodyStr);

                    if (Objects.isNull(authRequest.get("code"))) {
                        throw new OAuth2AuthenticationException(new OAuth2Error("authentication_code_missing"));
                    }
                    String registrationId = requestMatcher.matchAndExtract(exchange.getRequest().getPath()).getUriVariables().get(registrationIdUriVariableName);
                    if (Objects.isNull(registrationId)) {
                        throw new OAuth2AuthenticationException(new OAuth2Error("client_registration_not_found"));
                    }
                    Mono<ClientRegistration> clientRegistrationMono = clientRegistrationRepository.findByRegistrationId(registrationId);
                    if (Objects.isNull(clientRegistrationMono)) {
                        throw new OAuth2AuthenticationException(new OAuth2Error("client_registration_not_found"));
                    }

                    Mono<OAuth2AuthorizationRequest> authorizationRequestMono = authorizationRequestResolver.resolve(exchange, registrationId);
                    authorizationRequestMono.subscribe(authorizationRequest -> {
                        OAuth2AuthorizationResponse authorizationResponse = OAuth2AuthorizationResponse
                                .success(authRequest.get("code"))
                                .redirectUri(redirectUri)
                                .state(authorizationRequest.getState())
                                .build();

                        clientRegistrationMono.subscribe(clientRegistration -> {
                            OAuth2LoginAuthenticationToken authenticationRequest = new OAuth2LoginAuthenticationToken(clientRegistration,
                                    new OAuth2AuthorizationExchange(authorizationRequest, authorizationResponse));

                            OAuth2LoginAuthenticationToken authenticationResult = (OAuth2LoginAuthenticationToken) authenticationManager.authenticate(authenticationRequest);

                            String username = authenticationResult.getPrincipal().getAttribute("email");
                            UserDetails user = loadUser(username);
                            if (Objects.isNull(user)) {
                                user = createUser(authenticationResult);
                            }
                            Collection<GrantedAuthority> authorities = mergeAuthorities(authenticationResult, user);

                            OAuth2AuthenticationToken oauth2Authentication = new OAuth2AuthenticationToken(
                                    authenticationResult.getPrincipal(),
                                    authorities,
                                    authenticationResult.getClientRegistration().getRegistrationId());


                            OAuth2AuthorizedClient authorizedClient = new OAuth2AuthorizedClient(
                                    authenticationResult.getClientRegistration(),
                                    oauth2Authentication.getName(),
                                    authenticationResult.getAccessToken(),
                                    authenticationResult.getRefreshToken());

                            authorizedClientRepository.saveAuthorizedClient(authorizedClient, oauth2Authentication, exchange);

                            successfulAuthentication(exchange, oauth2Authentication);
                        });
                    });
                });
    }

    private Map<String, String> fromByteArrayJson(byte[] json) {
        try {
            return objectMapper.readValue(json, new TypeReference<HashMap<String, String>>() {});
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String toRaw(DataBuffer body) {
        byte[] bytes = new byte[body.readableByteCount()];
        body.read(bytes);
        DataBufferUtils.release(body);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private UserDetails loadUser(String username) {
        try {
            return userDetailsService.findByUsername(username).block();
        } catch (UsernameNotFoundException e) {
            return null;
        }
    }

    private UserDetails createUser(OAuth2LoginAuthenticationToken authentication) {
        Map<String, Object> attributes = authentication.getPrincipal().getAttributes();
        String username = (String) attributes.get("email");
        Member user = new Member(
                username,
                authentication.getClientRegistration().getRegistrationId(),
                (String) attributes.get("name"),
                Collections.singletonList("ROLE_USER"));
        memberRepository.save(user);

        return userDetailsService.findByUsername(username).block();
    }

    private Collection<GrantedAuthority> mergeAuthorities(OAuth2LoginAuthenticationToken authentication, UserDetails user) {
        Set<GrantedAuthority> authorities = new HashSet<>();
        authorities.addAll(authentication.getAuthorities());
        authorities.addAll(user.getAuthorities());
        return authorities;
    }

    private void successfulAuthentication(ServerWebExchange exchange, OAuth2AuthenticationToken authentication) {
        ReactiveSecurityContextHolder.withAuthentication(authentication);

        String token = tokenManager.generate(authentication);
        tokenManager.set(token, authentication);

        //exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);
        try {
            exchange.getResponse().writeWith(Flux.just(
                    exchange.getResponse()
                            .bufferFactory()
                            .wrap(objectMapper
                                    .writeValueAsString(new TokenResponse(token))
                                    .getBytes(StandardCharsets.UTF_8)
                            )));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    private void unsuccessfulAuthentication(ServerWebExchange exchange, Exception exception) {
        ReactiveSecurityContextHolder.clearContext();
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        exchange.getResponse().writeWith(Flux.just(
                exchange.getResponse()
                        .bufferFactory()
                        .wrap(exception
                                .getMessage()
                                .getBytes(StandardCharsets.UTF_8)
                        )));
    }

    private static class TokenResponse {
        private final String token;

        public TokenResponse(String token) {
            this.token = token;
        }

        public String getToken() {
            return token;
        }
    }
}
