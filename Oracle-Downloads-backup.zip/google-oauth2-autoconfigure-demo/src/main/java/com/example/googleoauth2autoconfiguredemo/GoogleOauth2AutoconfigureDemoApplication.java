package com.example.googleoauth2autoconfiguredemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoogleOauth2AutoconfigureDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoogleOauth2AutoconfigureDemoApplication.class, args);
	}

}
