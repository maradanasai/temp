package com.example.googleoauth2autoconfiguredemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoogleOauth2AutoconfigureDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
