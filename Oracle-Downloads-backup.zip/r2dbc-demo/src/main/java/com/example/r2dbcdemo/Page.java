package com.example.r2dbcdemo;

import org.springframework.data.annotation.Id;

public class Page {
    @Id
    private Integer id;
    private String content;
}
