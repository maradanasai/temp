package com.example.r2dbcdemo;

import org.springframework.data.annotation.Id;

import java.util.List;

public class Book {
    @Id
    private Integer id;
    private List<Page> list;
}
