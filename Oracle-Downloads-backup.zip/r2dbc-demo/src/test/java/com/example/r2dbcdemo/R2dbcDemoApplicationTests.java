package com.example.r2dbcdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class R2dbcDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
