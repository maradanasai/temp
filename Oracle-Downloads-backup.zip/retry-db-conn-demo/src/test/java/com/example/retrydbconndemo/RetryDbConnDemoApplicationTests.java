package com.example.retrydbconndemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetryDbConnDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
