package com.example.springcloudgatewayoauth2demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.util.function.Supplier;
import java.util.stream.Stream;

@RestController
@RequestMapping("/")
public class TestController {
	/*@GetMapping
	public String value() {
		return "Hello world!";
	}*/

	@GetMapping("/user")
	public Principal user(Principal principal) {
		return principal;
	}
}