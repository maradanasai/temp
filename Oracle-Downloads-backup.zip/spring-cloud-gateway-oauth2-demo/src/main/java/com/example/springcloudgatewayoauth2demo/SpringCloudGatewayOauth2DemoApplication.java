package com.example.springcloudgatewayoauth2demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudGatewayOauth2DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudGatewayOauth2DemoApplication.class, args);
	}


}
