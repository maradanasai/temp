package com.example.springcloudgatewayoauth2demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudGatewayOauth2DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
