package com.example.demoresourceserver;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

	@GetMapping("/")
	@PreAuthorize("hasRole('STUDENT')")
	public String index() {
		return "User access it is";
	}

	@GetMapping("/admin")
	@PreAuthorize("hasRole('ADMIN')")
	public String getAdminAccess() {
		return "Admin access it is";
	}
}