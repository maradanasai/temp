package com.example.demoresourceserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoResourceServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
