rootProject.name = "oauth2-sso-example"
