package com.example.demojpa.repository.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Book {
    @Id
    @EqualsAndHashCode.Include
    @Column(name = "book_id")
    private String bookId;

    private String name;

    @OneToMany(targetEntity = Page.class, cascade= CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "book_id_fk", referencedColumnName = "book_id")
    private List<Page> pages;
}
