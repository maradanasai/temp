package com.example.demojpa.controller;

import com.example.demojpa.repository.PageRepository;
import com.example.demojpa.repository.entity.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/page")
public class PageController {
    @Autowired
    private PageRepository pageRepository;

    @GetMapping
    public List<Page> getPages() {
        return pageRepository.findAll();
    }

    @GetMapping("/{bookId}")
    public List<Page> getPagesBy(@PathVariable String bookId) {
        return pageRepository.findPagesByBookId(bookId);
    }
}
