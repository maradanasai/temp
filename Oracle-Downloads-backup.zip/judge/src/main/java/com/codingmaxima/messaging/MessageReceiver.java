package com.codingmaxima.messaging;

import com.codingmaxima.core.JudgeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Base64;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

public class MessageReceiver implements MessageListener {
    private static final Logger LOG = LoggerFactory.getLogger(MessageReceiver.class);

    public static final String SUBMISSION_ID_FIELD = "submission_id";
    public static final String PROBLEM_ID_FIELD = "problem_id";
    public static final String SOLUTION_CODE_FIELD = "solution_code";
    public static final String LANGUAGE_ID_FIELD = "language_id";
    public static final String TIME_LIMIT_FIELD = "time_limit";
    public static final String SPACE_LIMIT_FIELD = "space_limit";
    public static final String TEST_CASES_PER_PROB = "test_cases";

    @Autowired
    private JudgeService judgeService;

    private static final AtomicInteger requestCount = new AtomicInteger();
    private static final LongAdder duration = new LongAdder();

    @Override
    public void onMessage(Message message) {
        if (message instanceof MapMessage) {
            MapMessage request = (MapMessage) message;
                Thread.startVirtualThread(() -> {
                    //LOG.info("Spawn thread: " + Thread.currentThread());
                    try {
                        LOG.info("Request received: " + request.getString(SUBMISSION_ID_FIELD));
                        long start = System.currentTimeMillis();
                        judgeService.judge(fromMapMessage(request));
                        long end = System.currentTimeMillis();
                        LOG.info("Request no: " + requestCount.incrementAndGet());
                        duration.add(end - start);
                        LOG.info("Total avg. time: " + (duration.longValue() / requestCount.get()));
                    } catch (JMSException | IOException | InterruptedException e) {
                        LOG.error("Something went wrong :((", e);
                    } catch (Exception e) {
                        LOG.error("Error: ", e);
                    }
                });
        } else {
            LOG.error("Invalid message receiver format: {}", message);
        }
    }

    private static final Base64.Decoder decoder = Base64.getDecoder();

    private static Map<String, Object> fromMapMessage(MapMessage message) throws JMSException {
        Map<String, Object> result = new HashMap<>();
        result.put(SUBMISSION_ID_FIELD, message.getString(SUBMISSION_ID_FIELD));
        result.put(PROBLEM_ID_FIELD, message.getString(PROBLEM_ID_FIELD));
        result.put(SOLUTION_CODE_FIELD, new String(decoder.decode(message.getString(SOLUTION_CODE_FIELD))));
        result.put(LANGUAGE_ID_FIELD, message.getString(LANGUAGE_ID_FIELD));
        result.put(SPACE_LIMIT_FIELD, message.getInt(SPACE_LIMIT_FIELD));
        result.put(TIME_LIMIT_FIELD, message.getInt(TIME_LIMIT_FIELD));
        if (message.itemExists("test")) {
            result.put("test", true);
            result.put(TEST_CASES_PER_PROB, message.getObject(TEST_CASES_PER_PROB));
        }
        return result;
    }
}
