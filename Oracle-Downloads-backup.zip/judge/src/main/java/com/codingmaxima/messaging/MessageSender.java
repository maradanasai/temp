package com.codingmaxima.messaging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import java.lang.management.ManagementFactory;
import com.sun.management.OperatingSystemMXBean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.time.Instant;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.codingmaxima.core.Runner.RESULT_SUBMISSION_ID;

@Component
public class MessageSender {
    private static final Logger LOG = LoggerFactory.getLogger(MessageSender.class);

    private static final String HEARTBEAT_EVENT = "heartbeat";
    private static final String JUDGE_ID = "judge_id";
    private static final String PROCESS_CPU_LOAD = "process_cpu_load";
    private static final String SYSTEM_CPU_LOAD = "system_cpu_load";
    private static final String SYSTEM_AVG_LOAD = "system_avg_load";
    private static final String FREE_MEMORY = "free_memory";
    private static final String TOTAL_MEMORY = "total_memory";

    private final String judgeId = UUID.randomUUID().toString();

    @Value("${heartbeat.frequency.in.mins}")
    private int heartbeatFrequencyInMins;

    @Autowired
    private JmsTemplate jmsTemplate;

    public void sendMessage(final Map<String, Object> result) {
        jmsTemplate.convertAndSend(result);
    }

    public void sendMessage(String submissionId, String messageType, String description) {
        Map<String, String> result = new HashMap<>(2);
        result.put(RESULT_SUBMISSION_ID, submissionId);
        result.put(messageType, description);
        jmsTemplate.convertAndSend(result);
    }

    private boolean isApplicationRunning = true;

    @PostConstruct
    public void heartbeatsProducer() {
        Thread.startVirtualThread(() -> {
            while (isApplicationRunning) {
                Map<String, Object> result = new HashMap<>();
                result.put(JUDGE_ID, judgeId);
                result.put(HEARTBEAT_EVENT, Instant.now().atZone(ZoneId.of("Asia/Kolkata")).toString());

                OperatingSystemMXBean os = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
                result.put(PROCESS_CPU_LOAD, os.getProcessCpuLoad() * 100);
                result.put(SYSTEM_CPU_LOAD, os.getCpuLoad() * 100);
                result.put(SYSTEM_AVG_LOAD, os.getSystemLoadAverage());
                result.put(FREE_MEMORY, os.getFreeMemorySize());
                result.put(TOTAL_MEMORY, os.getTotalMemorySize());
                LOG.info("Sending heartbeat event from judge id: " + judgeId);
                sendMessage(result);
                sleep(heartbeatFrequencyInMins * 60 * 1000);
            }
        });
    }

    private void sleep(int timeInMillis) {
        try {
            Thread.sleep(timeInMillis);
        } catch (InterruptedException e1) {
            LOG.error("Exception in heartbeat executor", e1);
        }
    }

    @PreDestroy
    public void setAlive() {
        isApplicationRunning = false;
    }
}
