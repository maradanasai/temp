package com.codingmaxima.service;

import com.codingmaxima.core.model.TestCaseInfoSchema;
import com.codingmaxima.model.TestcaseEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Arrays;
import java.util.stream.Collectors;

import static com.codingmaxima.core.Runner.*;

@Component
public class TestcaseDownloader {
    private static final Logger LOG = LoggerFactory.getLogger(TestcaseDownloader.class);

    private static final int DOWNLOAD_TESTS_PAGE_LIMIT = 15;
    private static final String BASE = "/judge";
    private static final String DOWNLOAD_ALL_TESTS_IN_CHUNKS_URL = BASE + "/testcases/{offset}/{limit}";
    private static final String DOWNLOAD_ALL_TESTS_BY_PROBLEM_ID_URL = BASE + "/testcases/{problemId}";
    private static final String GET_ALL_PROBLEM_IDS_URL = BASE + "/problem/ids";

    @Value("${test_case_dir}")
    private String testcaseStorageDir;

    @Value("${codingmaxima.app.url}")
    private String codingmaximaAppUrl;

    @Autowired
    private ObjectMapper objectMapper;

    private RestTemplate client;

    @PostConstruct
    private void init() {
        this.client = new RestTemplateBuilder()
                .rootUri(codingmaximaAppUrl)
                .build();
        Thread.startVirtualThread(this::downloadAllTestsRunner);
    }

    private void downloadAllTestsRunner() {
        for (int i = 1, limit = 10; i <= limit; i++) {
            try {
                ResponseEntity<String> response = client.getForEntity("/ping", String.class);
                if (response.getStatusCode() == HttpStatus.OK) {
                    LOG.info("codingmaxima backend app ping: " + response.getBody());
                    downloadAllTestcases();
                    return;
                } else {
                    RetryAfter(5000);
                }
            } catch (RestClientException e) {
                LOG.error("Ping failed!, try again", e);
                RetryAfter(5000);
                if (i >= limit) throw e;
            }
        }
    }

    private void RetryAfter(int timeInMillis) {
        try {
            Thread.sleep(timeInMillis);
        } catch (InterruptedException e1) {
            LOG.error("Exception in RetryAfter", e1);
        }
    }

    @Scheduled(cron = "0 0 3 * * *")
    public void syncAllTestcases() {
        LOG.info("Start synching all testcases with db ...");
        try {
            String[] allProblemIdsResponse = client.getForEntity(GET_ALL_PROBLEM_IDS_URL, String[].class).getBody();
            Set<String> allProblemIds = Arrays.stream(allProblemIdsResponse)
                    .collect(Collectors.toSet());
            Files.walk(Paths.get(testcaseStorageDir), 1)
                    .filter(Files::isDirectory)
                    .filter(path -> !allProblemIds.contains(path.getFileName().toString()))
                    .forEach(path -> {
                        try {
                            FileSystemUtils.deleteRecursively(path);
                        } catch (IOException e) {
                            LOG.error("Exception in deleting problem testcase dir for problem id: " + path.getFileName(), e);
                        }
                    });
        } catch (IOException | RuntimeException e) {
            LOG.error("Exception in synching of testcases", e);
        }
    }

    public void downloadAllTestcases() {
        try {
            Files.createDirectories(Paths.get(testcaseStorageDir));

            int offset = 0;
            while (true) {
                ResponseEntity<TestcaseEntity[]> response = client.getForEntity(DOWNLOAD_ALL_TESTS_IN_CHUNKS_URL, TestcaseEntity[].class, offset, DOWNLOAD_TESTS_PAGE_LIMIT);
                Map<String, List<TestcaseEntity>> testcases = Arrays.stream(response.getBody())
                        .collect(Collectors.groupingBy(TestcaseEntity::problemId, Collectors.toList()));
                testcases.forEach((k, v) -> this.writeAllTestcasesInfoToDisk(v));

                if (testcases.size() < DOWNLOAD_TESTS_PAGE_LIMIT) break;

                offset += DOWNLOAD_TESTS_PAGE_LIMIT;
            }
            LOG.info("testcases data dump completed at: " + LocalDateTime.now());
        } catch (Exception e) {
            LOG.error("Unable to dump the testcases data", e);
        }
    }

    public boolean downloadAllTestcasesFor(String problemId) {
        ResponseEntity<TestcaseEntity[]> response = client.getForEntity(DOWNLOAD_ALL_TESTS_BY_PROBLEM_ID_URL, TestcaseEntity[].class, problemId);
        List<TestcaseEntity> testcases = Arrays.asList(response.getBody());
        if (testcases.isEmpty()) {
            return false;
        }

        writeAllTestcasesInfoToDisk(testcases);
        return true;
    }

    public boolean writeAllTestcasesInfoToDisk(List<TestcaseEntity> testcases) {
        final String problemId = testcases.get(0).problemId();
        try {
            Path problemTestcaseDir = Paths.get(testcaseStorageDir, problemId);
            if (Files.exists(problemTestcaseDir)) {
                FileSystemUtils.deleteRecursively(problemTestcaseDir);
            }
            Files.createDirectory(problemTestcaseDir);
        } catch (IOException e) {
            LOG.error("Error creating problem testcase dir", e);
            return false;
        }
        List<TestCaseInfoSchema> schemaEntityList = testcases.stream()
                .peek(testcaseEntity -> {
                    try {
                        Files.write(Paths.get(testcaseStorageDir, problemId, testcaseEntity.testcaseNo() + TESTCASE_INPUT_FILE_EXT),
                                testcaseEntity.input().getBytes());
                        Files.write(Paths.get(testcaseStorageDir, problemId, testcaseEntity.testcaseNo() + TESTCASE_OUTPUT_FILE_EXT),
                                testcaseEntity.output().getBytes());
                    } catch (IOException e) {
                        LOG.error("Error creating testcase file", e);
                    }
                })
                .map(entity -> new TestCaseInfoSchema()
                        .testCaseNumber(entity.testcaseNo())
                        .inputFileName(entity.testcaseNo() + TESTCASE_INPUT_FILE_EXT)
                        .outputFileName(entity.testcaseNo() + TESTCASE_OUTPUT_FILE_EXT)
                        .points(entity.marks())
                )
                .collect(Collectors.toList());
        try {
            objectMapper.writeValue(Paths.get(testcaseStorageDir, problemId, problemId + TEST_CASE_INFO_FILE_EXT).toFile(), schemaEntityList);
        } catch (IOException e) {
            LOG.error("Error creating testcase info file", e);
            return false;
        }
        return true;
    }
}
