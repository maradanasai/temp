package com.codingmaxima.core;

import com.codingmaxima.service.TestcaseDownloader;
import com.codingmaxima.model.TestcaseEntity;
import com.codingmaxima.messaging.MessageSender;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

import static com.codingmaxima.core.LanguageConfig.*;
import static com.codingmaxima.core.Runner.*;
import static com.codingmaxima.messaging.MessageReceiver.*;

@Service
public class JudgeService {
    private static final Logger LOG = LoggerFactory.getLogger(JudgeService.class);

    @Autowired
    private Compiler compiler;

    @Autowired
    private Runner runner;

    @Autowired
    private MessageSender messageSender;

    @Autowired
    private TestcaseDownloader testcaseDownloader;

    @Value("${test_case_dir}")
    public String TEST_CASE_DIR;

    @Value("${judger_workspace_base}")
    public String JUDGER_WORKSPACE_BASE;

    @Value("${codingmaxima.app.debug}")
    private boolean debug;

    private Set<String> supportedProblems;

    @PostConstruct
    public void init() throws IOException {
        supportedProblems = Files.list(Paths.get(TEST_CASE_DIR))
                .filter(Files::isDirectory)
                .map(path -> path.getFileName().toString())
                .collect(Collectors.toSet());
    }

    @Autowired
    private ObjectMapper objectMapper;

    public void judge(final Map<String, Object> request) throws IOException, InterruptedException {
        if (!supportedProblems.contains((String) request.get(PROBLEM_ID_FIELD)) && !request.containsKey("test")) {
            if (!testcaseDownloader.downloadAllTestcasesFor((String) request.get(PROBLEM_ID_FIELD))) {
                LOG.error("Invalid problem id: " + request.get(PROBLEM_ID_FIELD));
                messageSender.sendMessage((String) request.get(SUBMISSION_ID_FIELD), RESULT_ERROR,
                        "Invalid problem id: " + request.get(PROBLEM_ID_FIELD));
                return;
            }
            supportedProblems.add((String) request.get(PROBLEM_ID_FIELD));
        } else if (request.containsKey("test")) {
            List<Map<String, String>> allTests = (List<Map<String, String>>) request.get(TEST_CASES_PER_PROB);
            if (!testcaseDownloader.writeAllTestcasesInfoToDisk(
                    allTests
                            .stream()
                            .map(map -> objectMapper.convertValue(map, TestcaseEntity.class))
                            .collect(Collectors.toList()))) {
                LOG.error("Error writing all testcases to disk for problem id {}", request.get(PROBLEM_ID_FIELD));
                return;
            }
            supportedProblems.add((String) request.get(PROBLEM_ID_FIELD));
        }

        Map<String, String> compileConfig;
        Map<String, String> runConfig;
        List<String> env;
        if (SUPPORTED_LANGUAGES.containsKey((String) request.get(LANGUAGE_ID_FIELD))) {
            compileConfig = SUPPORTED_LANGUAGES.get((String) request.get(LANGUAGE_ID_FIELD)).getT1().getT1();
            runConfig = SUPPORTED_LANGUAGES.get((String) request.get(LANGUAGE_ID_FIELD)).getT1().getT2();
            env = SUPPORTED_LANGUAGES.get((String) request.get(LANGUAGE_ID_FIELD)).getT2();
        } else {
            LOG.error("Language: " + request.get(LANGUAGE_ID_FIELD) + " not supported by Judge");
            messageSender.sendMessage((String) request.get(SUBMISSION_ID_FIELD), RESULT_ERROR,
                    "Language: " + request.get(LANGUAGE_ID_FIELD) + " not supported by Judge");
            return;
        }

        String execPath;
        if (Objects.nonNull(compileConfig)) {
            Path path = Paths.get(JUDGER_WORKSPACE_BASE, (String) request.get(SUBMISSION_ID_FIELD), compileConfig.get("src_name"));
            Files.createDirectory(path.getParent());
            Files.write(path, ((String)request.get(SOLUTION_CODE_FIELD)).getBytes());
            execPath = compiler.compile((String) request.get(SUBMISSION_ID_FIELD),
                    compileConfig,
                    path.toString(),
                    Paths.get(JUDGER_WORKSPACE_BASE, (String) request.get(SUBMISSION_ID_FIELD)).toString());
        } else {
            Path path = Paths.get(JUDGER_WORKSPACE_BASE, (String) request.get(SUBMISSION_ID_FIELD), runConfig.get("exe_name"));
            execPath = path.toString();
            Files.write(path, ((String)request.get(SOLUTION_CODE_FIELD)).getBytes());
        }

        if (Objects.isNull(execPath) || execPath.isEmpty()) {
            return;
        }

        try {
            runner.run(runConfig, execPath, env, request);
        } catch (Exception e) {
            LOG.error("Exception in Runner: ", e);
        } finally {
            /*if (request.containsKey("test")) {
                Files.walk(Paths.get(TEST_CASE_DIR, (String) request.get(PROBLEM_ID_FIELD)))
                        .sorted(Comparator.reverseOrder())
                        .forEach(path -> {
                            try {
                                Files.delete(path);
                            } catch (IOException e) {
                                LOG.error("Unable to delete test case directory (add/update)", e);
                            }
                        });
                LOG.info("Removed the test case directory (add/update) for problem id: " + request.get(PROBLEM_ID_FIELD));
            }*/
            messageSender.sendMessage((String) request.get(SUBMISSION_ID_FIELD), RESULT_DONE,
                    "All testcases are processed for problem id: " + request.get(PROBLEM_ID_FIELD) +
                            ", and submission id: " + request.get(SUBMISSION_ID_FIELD));
        }
    }
}
