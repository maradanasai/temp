package com.codingmaxima.core;

import com.codingmaxima.messaging.MessageSender;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.codingmaxima.core.Runner.JUDGE_RESULT_STATUS_CODE;
import static com.codingmaxima.core.Runner.RESULT_COMPILE;


@Component
public class Compiler {
    private static final Logger LOG = LoggerFactory.getLogger(Compiler.class);

    @Autowired
    private Judge judge;

    @Autowired
    private MessageSender messageSender;

    @Autowired
    private ObjectMapper objectMapper;

    @Value("${compiler_log_path}")
    public String COMPILER_LOG_PATH;

    public String compile(String submissionId, Map<String, String> compileConfig, String srcPath, String outputDir)
            throws IOException, InterruptedException {
        Path exePath = Paths.get(outputDir, compileConfig.get("exe_name"));
        String[] command = compileConfig.get("compile_command")
                .replace("{src_path}", srcPath)
                .replace("{exe_dir}", outputDir)
                .replace("{exe_path}", exePath.toString())
                .split(" ");

        Path compilerOut = Paths.get(outputDir, "compiler.out");
        // os.chdir(output_dir); TODO: not sure
        List<String> env = Collections.singletonList("PATH=" + System.getenv("PATH"));
        Map<String, Object> status = judge.run(
                Integer.parseInt(compileConfig.get("max_cpu_time")),
                Integer.parseInt(compileConfig.get("max_real_time")),
                Integer.parseInt(compileConfig.get("max_memory")),
                128 * 1024 * 1024,
                1 * 1024 * 1024,
                Judge.UNLIMITED,
                command[0],
                srcPath,
                compilerOut.toString(),
                compilerOut.toString(),
                command,
                env,
                COMPILER_LOG_PATH,
                null,
                0,
                0,
                0);

        if ((int)status.get(JUDGE_RESULT_STATUS_CODE) != Judge.RESULT_SUCCESS) {
            if (Files.exists(compilerOut)) {
                String error = new String(Files.readAllBytes(compilerOut));
                if (!error.isEmpty()) {
                    messageSender.sendMessage(submissionId, RESULT_COMPILE, error);
                    return null;
                }
            }
            LOG.error("Compiler runtime error, status: {}, problem path: {}, result: {}",
                    Judge.toResultStatusDescription((int)status.get(JUDGE_RESULT_STATUS_CODE)), srcPath, status);
            messageSender.sendMessage(submissionId, RESULT_COMPILE, "Compiler runtime error, info: " +
                    Judge.toResultStatusDescription((int)status.get(JUDGE_RESULT_STATUS_CODE)));
            return null;
        } else {
            messageSender.sendMessage(submissionId, RESULT_COMPILE, "compiled successfully");
            return exePath.toString();
        }
    }
}
