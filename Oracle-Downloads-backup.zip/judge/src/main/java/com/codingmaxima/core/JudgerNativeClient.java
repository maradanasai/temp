package com.codingmaxima.core;

import java.util.Arrays;

/*
* Do not change this class name including package
 */
public class JudgerNativeClient {

    public static final String NATIVE_JUDGE_PATH = "/usr/lib/judger/libjudger.so";

    static {
        System.load(NATIVE_JUDGE_PATH);
    }

    public static void main(String[] args) {
        int[] result = judge(
                -1,
                -1,
                -1,
                -1,
                -1,
                -1,
                0,
                "/usr/lib/jvm/bin/java",
                "/home/rajeev/Desktop/judger/testcase/aplusb/1.in",
                "/home/rajeev/Desktop/judger/run/test/1.out",
                "/home/rajeev/Desktop/judger/run/test/1.out",
                new String[]{ "/home/rajeev/Desktop/judger/run/test", "-XX:MaxRAM=262144k", "-Dfile.encoding=UTF-8", "-Djava.awt.headless=true", "Main" },
                new String[]{ "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "LANG=en_US.UTF-8", "LANGUAGE=en_US:en", "LC_ALL=en_US.UTF-8" },
                "/home/rajeev/Desktop/judger/run/logs/run.log",
                null,
                0,
                0
        );
        System.out.println("Judge result: " + Arrays.toString(result));
    }

    /*
    * Do not change this method
     */
    public static native int[] judge(
            int max_cpu_time,
            int max_real_time,
            int max_memory,
            int max_stack,
            int max_process_number,
            int max_output_size,
            int memory_limit_check_only,
            String exe_path,
            String input_file,
            String output_file,
            String error_file,
            String[] args,
            String[] env,
            String log_path,
            String seccomp_rule_name,
            int uid,
            int gid
    );
}