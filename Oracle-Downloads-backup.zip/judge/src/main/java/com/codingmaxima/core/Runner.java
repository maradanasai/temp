package com.codingmaxima.core;

import com.codingmaxima.core.model.TestCaseInfoSchema;
import com.codingmaxima.core.model.Tuple2;
import com.codingmaxima.messaging.MessageSender;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Map;
import java.util.Collections;

import static com.codingmaxima.core.Judge.*;
import static com.codingmaxima.messaging.MessageReceiver.*;

@Component
public class Runner {
    private static final Logger LOG = LoggerFactory.getLogger(Runner.class);

    public static final String JUDGE_RESULT_STATUS_CODE = "result";
    public static final String RESULT_SUBMISSION_ID = "submission_id";
    public static final String RESULT_PROBLEM_ID = "problem_id";
    public static final String RESULT_TESTCASE_NUMBER = "testcase_number";
    public static final String RESULT_INPUT = "input";
    public static final String RESULT_EXPECTED_OUTPUT = "expected_output";
    public static final String RESULT_ACTUAL_OUTPUT = "actual_output";
    public static final String RESULT_STATUS = "status";
    public static final String RESULT_CPU_TIME = "cpu_time";
    public static final String RESULT_MEMORY = "memory";
    public static final String RESULT_COMPILE = "compile";
    public static final String RESULT_ERROR = "error";
    public static final String RESULT_DONE = "done";

    public static final String TEST_CASE_INFO_FILE_EXT = ".info";
    public static final String TESTCASE_INPUT_FILE_EXT = ".in";
    public static final String TESTCASE_OUTPUT_FILE_EXT = ".out";

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private Judge judge;

    @Autowired
    private MessageSender messageSender;

    @Value("${judger_run_log_path}")
    public String JUDGER_RUN_LOG_PATH;

    @Value("${test_case_dir}")
    public String TEST_CASE_DIR;

    @Value("${judger_workspace_base}")
    public String JUDGER_WORKSPACE_BASE;

    public void run(Map<String, String> runConfig,
                    String execPath,
                    List<String> runEnv,
                    Map<String, Object> request) throws IOException {
        String submissionId = (String) request.get(SUBMISSION_ID_FIELD);
        String problemId = (String) request.get(PROBLEM_ID_FIELD);
        int maxCpuTime = (int) request.get(TIME_LIMIT_FIELD);
        int maxMemory = (int) request.get(SPACE_LIMIT_FIELD);
        String testCaseDir = Paths.get(TEST_CASE_DIR, (String) request.get(PROBLEM_ID_FIELD)).toString();
        String submissionDir = Paths.get(JUDGER_WORKSPACE_BASE, (String) request.get(SUBMISSION_ID_FIELD)).toString();
        String testCasesInfoFileName = request.get(PROBLEM_ID_FIELD) + TEST_CASE_INFO_FILE_EXT;

        List<TestCaseInfoSchema> testCases =
                objectMapper.readValue(Files.readAllBytes(Paths.get(testCaseDir, testCasesInfoFileName)), new TypeReference<List<TestCaseInfoSchema>>(){});
        String[] command = runConfig.get("command")
                                .replace("{exe_path}", execPath)
                                .replace("{exe_dir}", execPath.substring(0, execPath.lastIndexOf("/")))
                                .replace("{max_memory}", String.valueOf(maxMemory / 1024))
                                .split(" ");
        List<String> env = new ArrayList<>();
        env.add("PATH=" + System.getenv("PATH"));
        env.addAll(runEnv);

        testCases
                .stream()
                .map(testCase -> {
                    Map<String, Object> result = null;
                    try {
                        result = judge.run(
                                maxCpuTime,
                                Judge.UNLIMITED,
                                maxMemory,
                                128 * 1024 * 1024,
                                1 * 1024 * 1024,
                                Judge.UNLIMITED,
                                command[0],
                                Paths.get(testCaseDir, testCase.testCaseNumber() + TESTCASE_INPUT_FILE_EXT).toString(),
                                Paths.get(submissionDir, testCase.testCaseNumber() + TESTCASE_OUTPUT_FILE_EXT).toString(),
                                Paths.get(submissionDir, testCase.testCaseNumber() + TESTCASE_OUTPUT_FILE_EXT).toString(),
                                command,
                                env,
                                JUDGER_RUN_LOG_PATH,
                                null,
                                0,
                                0,
                                0);
                    } catch (IOException | InterruptedException e) {
                        LOG.error("Runner Error: ", e);
                    }
                    return new Tuple2<>(testCase.testCaseNumber(), result);
                })
                .map(result -> {
                    try {
                        Map<String, Object> status = result.getT2();
                        if ((int) status.get(JUDGE_RESULT_STATUS_CODE) == Judge.RESULT_SUCCESS) {
                            if (Files.notExists(Paths.get(submissionDir, result.getT1() + TESTCASE_OUTPUT_FILE_EXT))) {
                                status.put(JUDGE_RESULT_STATUS_CODE, RESULT_WRONG_ANSWER);
                            } else {
                                Tuple2<Boolean, Tuple2<String, String>> compareOutputResult =
                                        compareOutput(Paths.get(testCaseDir, result.getT1() + TESTCASE_OUTPUT_FILE_EXT),
                                                Paths.get(submissionDir, result.getT1() + TESTCASE_OUTPUT_FILE_EXT));
                                if (!compareOutputResult.getT1()) {
                                    status.put(JUDGE_RESULT_STATUS_CODE, RESULT_WRONG_ANSWER);
                                }
                                status.put(RESULT_TESTCASE_NUMBER, result.getT1());
                                status.put(RESULT_INPUT, new String(Files.readAllBytes(Paths.get(testCaseDir, result.getT1() + TESTCASE_INPUT_FILE_EXT))));
                                status.put(RESULT_EXPECTED_OUTPUT, compareOutputResult.getT2().getT1());
                                status.put(RESULT_ACTUAL_OUTPUT, compareOutputResult.getT2().getT2());
                                status.put(RESULT_STATUS, status.get(JUDGE_RESULT_STATUS_CODE));
                            }
                        } else {
                            status.put(RESULT_TESTCASE_NUMBER, result.getT1());
                            status.put(RESULT_INPUT, new String(Files.readAllBytes(Paths.get(testCaseDir, result.getT1() + TESTCASE_INPUT_FILE_EXT))));
                            status.put(RESULT_EXPECTED_OUTPUT, new String(Files.readAllBytes(Paths.get(testCaseDir, result.getT1() + TESTCASE_OUTPUT_FILE_EXT))));
                            status.put(RESULT_STATUS, status.get(JUDGE_RESULT_STATUS_CODE));
                        }
                        return status;
                    } catch (IOException e) {
                        LOG.error("Runner Error: ", e);
                        return Collections.<String, Object>emptyMap();
                    }
                })
                .peek(event -> {
                    event.put(RESULT_SUBMISSION_ID, submissionId);
                    event.put(RESULT_PROBLEM_ID, problemId);
                    event.put(RESULT_STATUS, toResultStatuCode((int) event.get(RESULT_STATUS)));
                })
                .forEach(messageSender::sendMessage);
    }

    private static Tuple2<Boolean, Tuple2<String, String>> compareOutput(Path expectedOutputFilePath,
                                                                         Path actualOutputFilePath) throws IOException {
        byte[] expectedOutputFileContent = Files.readAllBytes(expectedOutputFilePath);
        byte[] actualOutputFileContent = Files.readAllBytes(actualOutputFilePath);
        boolean isAccepted = Arrays.equals(expectedOutputFileContent, actualOutputFileContent);
        return new Tuple2<>(isAccepted, new Tuple2<>(new String(expectedOutputFileContent), new String(actualOutputFileContent)));
    }

    private String toResultStatuCode(int status) {
        switch (status) {
            case RESULT_SUCCESS: return "AC";
            case RESULT_WRONG_ANSWER: return "WA";
            case RESULT_CPU_TIME_LIMIT_EXCEEDED:
            case RESULT_REAL_TIME_LIMIT_EXCEEDED: return "TLE";
            case RESULT_MEMORY_LIMIT_EXCEEDED: return "MLE";
            case RESULT_RUNTIME_ERROR: return "RE";
            case RESULT_SYSTEM_ERROR: return "SE";
            default: return "SE";
        }
    }
}
