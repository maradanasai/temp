package com.codingmaxima.core;

import com.codingmaxima.core.model.Tuple2;
import com.google.common.collect.ImmutableMap;

import java.util.Arrays;
import java.util.List;
import java.util.Map;


public class LanguageConfig {
    private static final Tuple2<Map<String, String>, Map<String, String>> JAVA_LANG_CONFIG = new Tuple2<>(
            ImmutableMap.of(
                            "src_name", "Main.java",
                            "exe_name", "Main",
                            "max_cpu_time", "-1",
                            "max_real_time", "-1",
                            "max_memory", "-1",
                            "compile_command", "/usr/lib/jvm/bin/javac {src_path} -d {exe_dir} -encoding UTF8"
            ), // compile config
            ImmutableMap.of(
                    "command", "/usr/lib/jvm/bin/java -cp {exe_dir} -XX:MaxRAM={max_memory}k " +
                            "-Dfile.encoding=UTF-8 -Djava.awt.headless=true Main",
                            "seccomp_rule", "",
                            "memory_limit_check_only", "1"
            )  // run config
    );

    private static final Tuple2<Map<String, String>, Map<String, String>> PYTHON3_LANG_CONFIG = new Tuple2<>(
            ImmutableMap.of(
                            "src_name", "solution.py",
                            "exe_name", "__pycache__/solution.cpython-36.pyc",
                            "max_cpu_time", "-1",
                            "max_real_time", "-1",
                            "max_memory", "134217728",
                            "compile_command", "/usr/bin/python3 -m py_compile {src_path}"
            ),
            ImmutableMap.of(
                            "command", "/usr/bin/python3 {exe_path}",
                            "seccomp_rule", "general"
            )
    );

    private static final Tuple2<Map<String, String>, Map<String, String>> C_LANG_CONFIG = new Tuple2<>(
            ImmutableMap.of(
                            "src_name", "main.c",
                            "exe_name", "main",
                            "max_cpu_time", "-1",
                            "max_real_time", "-1",
                            "max_memory", "134217728",
                            "compile_command", "/usr/bin/gcc -DONLINE_JUDGE -O2 -w -fmax-errors=3 -std=c99 {src_path} -lm -o {exe_path}"
            ), // compile config
            ImmutableMap.of(
                            "command", "{exe_path}",
                            "seccomp_rule", "c_cpp"
            ) // run config
    );

    private static final Tuple2<Map<String, String>, Map<String, String>> CPP_LANG_CONFIG = new Tuple2<>(
            ImmutableMap.of(
                            "src_name", "main.cpp",
                            "exe_name", "main",
                            "max_cpu_time", "-1",
                            "max_real_time", "-1",
                            "max_memory", "134217728",
                            "compile_command", "/usr/bin/g++ -DONLINE_JUDGE -O2 -w -fmax-errors=3 -std=c++11 {src_path} -lm -o {exe_path}"
            ),
            ImmutableMap.of(
                            "command", "{exe_path}",
                            "seccomp_rule", "c_cpp"
            )
    );

    private static final List<String> DEFAULT_LANG_ENV_CONFIG =
            Arrays.asList("LANG=en_US.UTF-8", "LANGUAGE=en_US:en", "LC_ALL=en_US.UTF-8");

    private static final List<String> JAVA_LANG_ENV_CONFIG = DEFAULT_LANG_ENV_CONFIG;
    private static final List<String> PYTHON3_LANG_ENV_CONFIG =
            Arrays.asList("PYTHONIOENCODING=UTF-8", "LANG=en_US.UTF-8", "LANGUAGE=en_US:en", "LC_ALL=en_US.UTF-8");
    private static final List<String> C_LANG_ENV_CONFIG = DEFAULT_LANG_ENV_CONFIG;
    private static final List<String> CPP_LANG_ENV_CONFIG = DEFAULT_LANG_ENV_CONFIG;

    public static final Map<String, Tuple2<Tuple2<Map<String, String>, Map<String, String>>, List<String>>> SUPPORTED_LANGUAGES =
            ImmutableMap.of(
                    "JAVA", new Tuple2<>(JAVA_LANG_CONFIG, JAVA_LANG_ENV_CONFIG),
                    "PYTHON3", new Tuple2<>(PYTHON3_LANG_CONFIG, PYTHON3_LANG_ENV_CONFIG),
                    "C", new Tuple2<>(C_LANG_CONFIG, C_LANG_ENV_CONFIG),
                    "CPP", new Tuple2<>(CPP_LANG_CONFIG, CPP_LANG_ENV_CONFIG)
                    );
}

