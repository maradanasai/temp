package com.codingmaxima.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class Judge {
    private static final Logger LOG = LoggerFactory.getLogger(Judge.class);

    static final int UNLIMITED = -1;
    static final int RESULT_SUCCESS = 0;
    static final int RESULT_WRONG_ANSWER = -1;
    static final int RESULT_CPU_TIME_LIMIT_EXCEEDED = 1;
    static final int RESULT_REAL_TIME_LIMIT_EXCEEDED = 2;
    static final int RESULT_MEMORY_LIMIT_EXCEEDED = 3;
    static final int RESULT_RUNTIME_ERROR = 4;
    static final int RESULT_SYSTEM_ERROR = 5;

    public Map<String, Object> run(int max_cpu_time,
                                   int max_real_time,
                                   int max_memory,
                                   int max_stack,
                                   int max_output_size,
                                   int max_process_number,
                                   String exe_path,
                                   String input_path,
                                   String output_path,
                                   String error_path,
                                   String[] args,
                                   List<String> env,
                                   String log_path,
                                   String seccomp_rule_name,
                                   int uid,
                                   int gid,
                                   int memory_limit_check_only) throws IOException, InterruptedException {

        int[] judgeResult = null;
        try {
            judgeResult = JudgerNativeClient.judge(
                    max_cpu_time,
                    max_real_time,
                    -1, // TODO: fix this
                    max_stack,
                    max_process_number,
                    max_output_size,
                    memory_limit_check_only,
                    exe_path,
                    input_path,
                    output_path,
                    error_path,
                    Arrays.copyOfRange(args, 1, args.length),
                    env.toArray(new String[env.size()]),
                    log_path,
                    seccomp_rule_name,
                    uid,
                    gid);
        } catch (RuntimeException e) {
            LOG.error("Error occurred while calling native judger", e);
        }

        final Map<String, Object> nativeJudgeResult = new HashMap<>();
        nativeJudgeResult.put("cpu_time", judgeResult[0]);
        nativeJudgeResult.put("real_time", judgeResult[1]);
        nativeJudgeResult.put("memory", judgeResult[2]);
        nativeJudgeResult.put("signal", judgeResult[3]);
        nativeJudgeResult.put("exit_code", judgeResult[4]);
        nativeJudgeResult.put("error", judgeResult[5]);
        nativeJudgeResult.put("result", judgeResult[6]);

        return nativeJudgeResult;
    }

    public static String toResultStatusDescription(int status) {
        switch (status) {
            case RESULT_SUCCESS:
                return "SUCCESS";
            case RESULT_WRONG_ANSWER:
                return "RESULT_WRONG_ANSWER";
            case RESULT_CPU_TIME_LIMIT_EXCEEDED:
                return "RESULT_CPU_TIME_LIMIT_EXCEEDED";
            case RESULT_REAL_TIME_LIMIT_EXCEEDED:
                return "RESULT_REAL_TIME_LIMIT_EXCEEDED";
            case RESULT_MEMORY_LIMIT_EXCEEDED:
                return "RESULT_MEMORY_LIMIT_EXCEEDED";
            case RESULT_RUNTIME_ERROR:
                return "RESULT_RUNTIME_ERROR";
            case RESULT_SYSTEM_ERROR:
                return "RESULT_SYSTEM_ERROR";
            default:
                return "Invalid status code: " + status;
        }
    }
}
