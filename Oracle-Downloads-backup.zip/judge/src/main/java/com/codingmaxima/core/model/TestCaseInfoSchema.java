package com.codingmaxima.core.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@Getter
@Setter
@NoArgsConstructor
@Accessors(fluent = true, chain = true)
public class TestCaseInfoSchema {
    @JsonProperty("testcase_no")
    private Integer testCaseNumber;

    @JsonProperty("input_file_name")
    private String inputFileName;

    @JsonProperty("output_file_name")
    private String outputFileName;

    @JsonProperty("points")
    private Integer points;
}
