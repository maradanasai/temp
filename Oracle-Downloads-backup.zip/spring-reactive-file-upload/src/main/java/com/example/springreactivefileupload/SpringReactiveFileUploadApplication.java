package com.example.springreactivefileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringReactiveFileUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringReactiveFileUploadApplication.class, args);
	}

}
