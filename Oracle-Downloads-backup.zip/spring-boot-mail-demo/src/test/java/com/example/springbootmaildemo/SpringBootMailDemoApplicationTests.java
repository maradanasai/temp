package com.example.springbootmaildemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMailDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
