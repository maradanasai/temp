#include <stdio.h>

int main(int argc, char *argv[]) {
    char input[1000];
    scanf("%s", input);
    printf("Hello %s\n", input);
    return 0;
}