#include <stdio.h>

int main() {
    int big_stack[1024 * 1024 * 20] = {0};
    printf("big stack");
    return 0;
}