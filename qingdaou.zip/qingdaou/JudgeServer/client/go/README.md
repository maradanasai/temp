# JudgeServer client for Golang

# Installation

Install:

```shell
go get -d github.com/QingdaoU/JudgeServer/client/go
```

Import:

```go
import "github.com/QingdaoU/JudgeServer/client/go"
```

# Examples

[examples](https://github.com/QingdaoU/JudgeServer/tree/master/client/go/examples)