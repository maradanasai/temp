import os
import pwd

import grp

JUDGER_WORKSPACE_BASE = "/tmp/judger/run"

COMPILER_LOG_PATH = "/tmp/compile.log"
JUDGER_RUN_LOG_PATH = "/tmp/judger.log"
SERVER_LOG_PATH = "/tmp/judge_server.log"

TEST_CASE_DIR = "/home/rajeev/Desktop/qingdaou/JudgeServer/server/test_case"
SPJ_SRC_DIR = "./judger/spj"
SPJ_EXE_DIR = "./judger/spj"
