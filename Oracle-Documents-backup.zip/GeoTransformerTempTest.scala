package com.oracle.ugbu.ouai.transform

import com.oracle.ugbu.ouai.common.AppUtils.FieldParameters
import com.oracle.ugbu.ouai.common.constants.{TransformGeoConstants, TransformerConstants}
import com.oracle.ugbu.ouai.common.{AppUtils, LogTestClassTiming, LogTestMethodTiming, SharedSparkSession}
import org.apache.spark.sql.catalyst.plans.Inner
import org.apache.spark.sql.functions.col
import org.junit.runner.RunWith
import org.scalatest.FunSuite
import org.scalatestplus.junit.JUnitRunner
import org.slf4j.{Logger, LoggerFactory}

import java.time.LocalDateTime
import scala.reflect.io.File


@RunWith(classOf[JUnitRunner])
class GeoTransformerTempTest
  extends FunSuite
    with LogTestClassTiming
    with LogTestMethodTiming
    with SharedSparkSession {
  val logger: Logger = LoggerFactory.getLogger(classOf[GeoTransformerTempTest])
  val gdeD1SPFileName = "D1_SP"
  val outputPath = "./build/transformed/"

  import sqlImplicits._

  val fieldsTupleParam = Array(
    FieldParameters(
      TransformerConstants.objName,
      TransformerConstants.dlObjName
    ),
    FieldParameters(
      TransformerConstants.timestamp,
      TransformerConstants.dlTimestamp
    )
  )

  override def beforeEach(): Unit = {
    super.beforeEach()
  }

  override def afterEach(): Unit = {
    super.afterEach()

  }

  override def beforeAll(): Unit = {
    val directory = File(outputPath)
    directory.deleteRecursively()
    super.beforeAll()
  }

  override def afterAll(): Unit = {
    /*val directory = File(outputPath)
    directory.deleteRecursively()*/
    super.afterAll()
  }

  // Test if the Transformer is Able to generate data frames
  /*test("TestCreationOfResultDataframes") {
    /*MoTransformer.transformDirectoryBased(
      sparkSsn,
      "./src/test/resources/D1_SP.json",
      outputDi
    )*/
    val optionalDataFrame = AppUtils.getDFFromJson(
      "./src/test/resources/d1spTest.json",
      sparkSsn
    )

    assert(optionalDataFrame.isDefined)
    val resultList: ListBuffer[(String, DataFrame)] = MoTransformer
      .getDF(
        sparkSsn,
        optionalDataFrame.get,
        fieldsTupleParam,
        TransformerConstants.data
      )

    assert(resultList.size == 8)
    resultList.foreach(dataTuple => {
      if (dataTuple._1 == gdeD1SPFileName) {
        // dataTuple._2.select("D1_SP_ID").show
        assert(dataTuple._2.count() == 10)
      }
    })
  }*/

  test ("transformGeoLatLongToDeltaTables") {
    val D1_SP = AppUtils.readDfFromDelta(
      sparkSsn,
      "./src/test/resources/D1_SP"
    )

    val CI_SP = AppUtils.readDfFromDelta(
      sparkSsn,
      "./src/test/resources/CI_SP"
    )

    val D1_SP_IDENTIFIER = AppUtils.readDfFromDelta(
      sparkSsn,
      "./src/test/resources/D1_SP_IDENTIFIER"
    )

    val CI_PREM_GEO = AppUtils.readDfFromDelta(
      sparkSsn,
      "./src/test/resources/CI_PREM_GEO"
    )

    val CI_SP_GEO = AppUtils.readDfFromDelta(
      sparkSsn,
      "./src/test/resources/CI_SP_GEO"
    )

    val allGeoLatLongRecords: Seq[(String, String, String, String, String, String)] =
      D1_SP
      .select(TransformGeoConstants.D1_SP_ID)
      .collect
      /*val allGeoLatLongRecords: Seq[(String, String, String, String, String, String)] =
        Seq(("963549596469"), ("000784183922"), ("001072538114")).toDF(TransformGeoConstants.D1_SP_ID)
      .select(TransformGeoConstants.D1_SP_ID)
      .collect*/
      .map(spId => {
          val result = D1_SP
            .join(D1_SP_IDENTIFIER, Seq(TransformGeoConstants.D1_SP_ID), Inner.sql)
            .join(CI_SP, CI_SP(TransformGeoConstants.SP_ID) === D1_SP_IDENTIFIER(TransformGeoConstants.ID_VALUE), Inner.sql)
            .filter(col(TransformGeoConstants.SP_ID_TYPE_FLG) === "D1EI" && col(TransformGeoConstants.D1_SP_ID) === spId.getString(0))
            .select(TransformGeoConstants.PREM_ID, TransformGeoConstants.SP_ID, TransformGeoConstants.D1_SP_ID)

          var output: (String, String, String, String, String, String) = null

          if (!isEmpty(result.head.get(0).toString)) {
            val temp = CI_PREM_GEO
              .select(TransformGeoConstants.GEO_VAL)
              .where(col(TransformGeoConstants.PREM_ID) === result.head.get(0).toString
                && col(TransformGeoConstants.GEO_TYPE_CD) === "LAT/LONG")
              .head(1)
            if (!temp.isEmpty) {
              val latlong: Array[String] = temp.head.getString(0).split(" ")
              output = (result.head.get(2).toString,
                result.head.get(1).toString,
                latlong(0),
                latlong(1),
                TransformGeoConstants.CI_PREM_GEO,
                LocalDateTime.now().toString)
            }
          }

          if (output == null && !isEmpty(result.head.get(1).toString)) {
            val temp = CI_SP_GEO
              .select(TransformGeoConstants.GEO_VAL)
              .where(col(TransformGeoConstants.SP_ID) === result.head.get(1).toString
                && col(TransformGeoConstants.GEO_TYPE_CD) === "LAT/LONG")
              .head(1)
            if (!temp.isEmpty) {
              val latlong: Array[String] = temp.head.getString(0).split(" ")
              output = (result.head.get(2).toString,
                result.head.get(1).toString,
                latlong(0),
                latlong(1),
                TransformGeoConstants.CI_SP_GEO,
                LocalDateTime.now().toString)
            }
          }

         if (output == null && !isEmpty(result.head.get(2).toString)) {
            val temp = D1_SP
              .select(TransformGeoConstants.D1_GEO_LAT, TransformGeoConstants.D1_GEO_LONG)
              .where(col(TransformGeoConstants.D1_SP_ID) === result.head.get(2).toString)
              .head(1)
           if (!temp.isEmpty) {
             output = (result.head.get(2).toString,
               result.head.get(1).toString,
               temp.head.get(0).toString,
               temp.head.get(1).toString,
               TransformGeoConstants.D1_SP,
               LocalDateTime.now().toString)
           }
          }

          if (output == null) {
            logger.info("No lat/long values for sp id: {}, ci sp id: {}, ci prem id: {}",
              result.head.get(2).toString, result.head.get(1).toString, result.head.get(0).toString)
          }
        output
      })
      .filter(e => e != null)
      .toSeq

      if (allGeoLatLongRecords.nonEmpty) {
        AppUtils
          .writeDfToDeltaOverwrite(
            sparkSsn,
            allGeoLatLongRecords.toDF(
              TransformGeoConstants.D1_SP_ID,
              TransformGeoConstants.CI_SP_ID,
              TransformGeoConstants.GEO_LAT,
              TransformGeoConstants.GEO_LONG,
              TransformGeoConstants.SOURCE,
              TransformGeoConstants.LAST_UPDATED),
            outputPath + TransformGeoConstants.X1_SP_GEO_DERIVED
          )
      }
  }

  def isEmpty(x: String): Boolean = x == null || x.trim.isEmpty
}
